import React, { useState } from "react";
import '../../index.css';
import Popup from 'reactjs-popup';
import { updateJob } from "../api/jobCalls";
import { sendEmail } from "../api/emailCalls";
import 'reactjs-popup/dist/index.css';

export default function JobElement({job, setJob, user}) {
    const [editing, setEiditing] = useState(false);

    const performJobUpdate = (event) => {
        //Prevent page reload
        var { title, name, openings, filled, description, requirements } = document.forms[0];
        const newJob = { ...job }
        newJob[job.title] = title.value;
        newJob[job.name] = name.value;
        newJob[job.openings] = openings.value;
        newJob[job.filled] = filled.value;
        newJob[job.description] = description.value;
        newJob[job.requirements] = requirements.value;

        setJob(newJob)
        updateJob(job)
        event.preventDefault();
    }

    
    const sendApplicantEmail = (event) => {
        event.preventDefault();
        const candidate = {
            candidateFirstName: event.target.elements.candidateFirstName.value,
            candidateLastName: event.target.elements.candidateLastName.value,
            candidateEmail: event.target.elements.candidateEmail.value
        }
        sendEmail(job, user, candidate);
    };


    const renderButtons = () => {
        if (user && user.type === 'Applicant') {
            return (
                <div>
                    <button type="button" onClick={() => (console.log("Apply"))}>Apply</button>
                </div>);
        } else if (user && user.type === 'Recruiter' && job.recruiterId === user.uid) {
            return (
                <div>
                    <ApplicantPopup />
                    {!editing && <button type="button" onClick={() => (setEiditing(true))}>Edit Job</button>}
                    {editing && <button type="submit" onClick={() => { (setEiditing(false)); performJobUpdate() }}>Submit Changes</button>}
                </div>
            );
        } else {
            return (
                <div>
                    <ApplicantPopup />
                </div>
            );
        }
    }

    const ApplicantPopup = () => (
            <Popup trigger={<button  type="button">Recommend Position</button>} modal nested position="right center">
                {
                    close => (
                        <div>
                            <form onSubmit={(event) => { close(); sendApplicantEmail(event) }}>
                                <fieldset>
                                <legend>Available Jobs</legend>
                                <ul>
                                    <li>
                                        <label htmlFor="candidateFirstName">Candidate First Name: </label>
                                        <input type="text" id="candidateFirstName" required />
                                    </li>
                                    <li>
                                        <label htmlFor="candidateLastName">Candidate Last Name: </label>
                                        <input type="text" id="candidateLastName" required />
                                    </li>
                                    <li>
                                        <label htmlFor="candidateEmail">Candidate Email: </label>
                                        <input type="email" id="candidateEmail" required />
                                    </li>
                                </ul>
                                </fieldset>
                                <div>
                                <button type="submit">
                                    Send Application
                                </button>
                            </div>
                            </form>
                        </div>
                    )
                }
            </Popup>
    );

    return (
        <React.Fragment>
            <div className="center-div">
            <form>
                <fieldset>
                    <legend>Available Jobs</legend>
                    <ul>
                        <li>
                            <label htmlFor="title">Title: </label>
                                <input type="text" id="title" defaultValue={job.title} required disabled={!editing} />
                        </li>
                        <li>
                            <label htmlFor="level">Level: </label>
                            <input type="text" id="name" defaultValue={job.level} required disabled={!editing}  />
                        </li>
                        <li>
                            <label htmlFor="openings">Openings: </label>
                            <input type="number" id="openings" defaultValue={job.openings} required  disabled={!editing} />
                        </li>
                        <li>
                            <label htmlFor="filled">Filled: </label>
                            <input type="text" id="filled" defaultValue={job.filled} required disabled={!editing}  />
                        </li>
                        <li>
                            <label htmlFor="description">Description: </label>
                            <input type="text" id="description" defaultValue={job.description} required  disabled={!editing} />
                        </li>
                        <li>
                            <label htmlFor="requirements">Requirements: </label>
                            <input type="text" id="requirements" defaultValue={job.requirements} required disabled={!editing}  />
                        </li>
                    </ul>
                </fieldset>
                {renderButtons()}
            </form>
        </div>
        </React.Fragment>
    );
}