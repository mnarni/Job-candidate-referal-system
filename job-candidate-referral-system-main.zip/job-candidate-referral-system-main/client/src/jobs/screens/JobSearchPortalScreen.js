import React, {useEffect, useState} from "react";
import JobElement from "../elements/JobElement";
import {getAllJobs} from "../api/jobCalls";


function JobSearchPortalScreen({user, setJob}) {
  const [jobs, setJobs] = useState([]);

  useEffect(() => {

    if (user) {
      getAllJobs(setJobs);
    }
  }, [user])

    return (
      <div>
        <div className="center-div">
        <ul>
        {jobs.map((job) => (
            <li key={job.jid}><JobElement job={job} user={user} /></li>
          ))}
      </ul>
      </div>
      </div>
    )
}
export default JobSearchPortalScreen;