export default function RecruiterViewJobsScreen() {
    return <h1>Recruiter View</h1>;
}

