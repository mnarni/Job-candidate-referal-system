import axios from "axios";

const header = {
    Accept: "application/json",
    "Content-Type": "application/json",
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': '*',
    'Access-Control-Allow-Methods': '*'
};

const client = axios.create({
    baseURL: "http://localhost:8008/api/jobs",
    withCredentials: false,
    ...header
});

export const getAllJobs = async (setJobs) => {
    let { data } = await client.get("/all ");
    setJobs(data)
}

export const getJob = async (jid) => {
    let { data } = await client.get("/", {
        params: { jid }
    })
    return data;
}

export const getJobsByRecruiter = async (rid, setJobs) => {
    let { data } = await client.get("/recruiter/" + rid)
    setJobs(data)
}

export const getOpenJobs = async () => {
    let { data } = await client.get("/open")
    return data;
}

export const getJobsByLevel = async (level) => {
    let { data } = await client.get("/level/", {
        params: { level }
    })
    return data;
}

export const getJobsByFilter = async (params) => {
    let { data } = await client.get("/level/", {
        params
    })
    return data;
}

export const createJob = async (params, setUser) => {
    var { name, email, password, accountType, storename, address } = params;

    let { data } = await client.post("/", {
        email,
        password,
        name,
        accountType,
        storename,
        address
    });
    setUser(data)
}

export const updateJob = async (params, setJob) => {
    var { jobUpdate, uid } = params;

    let { data } = await client.put("/", {
        jobUpdate,
        uid
    });
    return data
}

export const fetchStores = async (setStores) => {
    let { data } = await client.get("/store/all");
    setStores(data)
}

export const createOrder = async (params) => {
    var {
        totalPrice,
        items,
        customer,
        vendor,
        setCart
      } = params;

    let { data } = await client.post("/order/create", {
        totalPrice,
        items,
        customer,
        vendor
    });
    setCart({})
}

export const updateOrderStatus = async (params) => {
    let {order, status} = params
    let orderId = order.orderId
    let { data } = await client.put("/order/status", {
        orderId, status
    })
}

export const fetchStoreStock = async (params, setStock) => {
    let { data } = await client.get("/store/stock", {
        params
    });
    setStock(data)
}

export const updateItem = async (params) => {
    let {item, email} = params
    let { data } = await client.put("/store/stock/update", {
        item, email
    })
}


