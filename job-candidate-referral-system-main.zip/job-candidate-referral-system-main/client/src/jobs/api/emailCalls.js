import axios from "axios";

const header = {
    Accept: "application/json",
    "Content-Type": "application/json",
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': '*',
    'Access-Control-Allow-Methods': '*'
};

const client = axios.create({
    baseURL: "http://localhost:8008/api/emails",
    withCredentials: false,
    ...header
});

const applicationLink = "http://localhost:3008/applications/create";

export const sendEmail = async (job, user, candidate) => {
    var { candidateFirstName, candidateLastName, candidateEmail } = candidate;
    console.log(user)
    const jobId = job.jid;
    const jobTitle = job.title;
    const jobLevel = job.level;
    const recruiterName = user.firstName + " " + user.lastName;
    const recruiterId = user.eid;

    const emailData = {
        jobId,
        recruiterName,
        recruiterId,
        candidateFirstName,
        candidateLastName,
        candidateEmail,
        jobTitle,
        jobLevel,
        applicationLink
    }

    let { data } = await client.post("/send", emailData);
}