import React from "react";
import {useState} from "react";
import {BrowserRouter, Route, Routes} from "react-router-dom";

import "./App.css";
import "./home.css";

import HomePage from "./common/HomePage";
import TopNav from "./common/TopNav";
import LoginScreen from "./employees/screens/LoginScreen";
import JobSearchPortalScreen from "./jobs/screens/JobSearchPortalScreen";
import RecruiterViewJobsScreen from "./jobs/screens/RecruiterViewJobsScreen";
import ApplicationsMultiple from "./applications/views/ApplicationsMultiple";
import ApplicationSingle from "./applications/views/ApplicationSingle";
import Fo4Page from "./common/Fo4Page";
import CreateApplication from "./applications/components/CreateApplication";
import ApplicationDeleteSuccess from "./applications/views/ApplicationDeleteSuccess";
import Footer from "./common/Footer";

function App() {
    const [user, setUser] = useState({});
    const [job, setJob] = useState({});

    return (
        <div id="App" className="App container-fluid">
            <div id="page-wrap">
                <BrowserRouter>
                    <TopNav/>
                    <Routes>
                        <Route path="/" element={<HomePage/>}/>
                        <Route path="/applications" element={<ApplicationsMultiple/>}/>
                        <Route path="/applications/:appId" element={<ApplicationSingle/>}/>
                        <Route path="/applications/create" element={<CreateApplication/>}/>
                        <Route path="/applications/delete/success" element={<ApplicationDeleteSuccess/>}/>
                        <Route path="/login" element={<LoginScreen setUser={setUser} user={user}/>}/>
                        <Route path="/jobsportal" element={<JobSearchPortalScreen user={user} setJob={setJob}/>}/>
                        <Route path="/recruiter/jobs"
                               element={<RecruiterViewJobsScreen recruiter={user} setJob={setJob}/>}/>
                        <Route path="*" element={<Fo4Page/>}/>
                    </Routes>
                    <Footer/>
                </BrowserRouter>
            </div>
        </div>
    );
}

export default App;

