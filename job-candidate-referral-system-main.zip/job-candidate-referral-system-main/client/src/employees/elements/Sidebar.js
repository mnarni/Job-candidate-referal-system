import React from 'react';
import {slide as Menu} from 'react-burger-menu';
import {Link} from 'react-router-dom';
import {logoutUser} from '../api/calls';

export default function Sidebar({ user, setUser }) {
    if (user) {
        if (user.type==='Recruiter') {
            return (
                <Menu>
                <Link className="menu-item" to="/customer/nearbystores">
                    Home
                </Link>
    
                <Link className="menu-item" to="/customer/cart">
                    Job Portal
                </Link>
    
                <Link className="menu-item" to={"/customer/" + user.name + "/orders"}>
                    Created Jobs
                </Link>
                    
                <Link className="menu-item" to={"/customer/" + user.name + "/orders"}>
                    Applications
                </Link>
    
                <Link className="menu-item" to="/" onClick={(e) => logoutUser(user.email, setUser)}>
                    Logout
                </Link>
                </Menu>
            );
        } else {
            return (
                <Menu>
                <Link className="menu-item" to="/customer/nearbystores">
                    Home
                </Link>
    
                <Link className="menu-item" to="/customer/cart">
                    Job Portal
                </Link>

                <Link className="menu-item" to="/" onClick={(e) => logoutUser(user.email, setUser)}>
                    Logout
                </Link>
                </Menu>
            );
        }
    }
};