
import axios from "axios";



const header = {
    Accept: "application/json",
    "Content-Type": "application/json",
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': '*',
    'Access-Control-Allow-Methods': '*',
    timeout: 60000
};
export const client = axios.create({
    baseURL: "http://localhost:8008/api/employees",
    withCredentials: false,
    ...header
});


export const getAllUsers = async (setUsers) => {
    let { data } = await client.get("/");
    setUsers(data)
}
export const getUser = async (eid) => {
    let { data } = await client.get("/", {
        params: { eid }
    })
    return data;
}
export const getUserByEmail = async (email, data) => {
    await client.get("/email/" + email, {
    }).then((response) => {
        console.log(response);
    }).catch((error) => {
        console.log(error);
    });
}

export const createUser = async (params) => {
    var { firstName, lastName, email, title } = params;
    let { data } = await client.post("/", {
        firstName,
        lastName,
        email,
        title,
    });
}
export const authenticateUser = async (params, setUser) => {
    var { email, password } = params;
    getUserByEmail(params).then((response) => {
        console.log("Email");
        //setUser({authenticated:true});
    })
    let { data } = await client.get("/email/" + email, {
    });
    setUser(data);
    // .then((response) => {
    //     onsole.log(response);
    // }).catch((error) => {
    //     console.log(error);
    // });

}
export const logoutUser = () => {
}
