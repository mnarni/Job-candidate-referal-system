
import React, { useState } from "react";
import { createUser, authenticateUser } from "../api/calls";
import { useNavigate } from 'react-router-dom';
import '../../App.css';
function LoginScreen({ setUser, user }) {
  const [currentView, setCurrentView] = useState('logIn');
  const [isVendor, setIsVendor] = useState(false);
  const navigate = useNavigate();
  const handleLogin = (event) => {
    //Prevent page reload
    var { email, password } = document.forms[0];
    // Find user login info
    event.preventDefault();

    authenticateUser(email.value, password.value, setUser).then((response) => {
      console.log("Email");
      user.authenticated = response;
      if (user && user.authenticated === true) {
        navigate("/jobsportal")
      } else {
        console.error("User does not have an account or invalid credentials input")
      }
    });
  };
  React.useEffect(() => {
    if (user && user.authenticated === true) {
      navigate("/jobsportal")
    } else {
      console.error("User does not have an account or invalid credentials input")
    }
  });
  const handleSignup = (event) => {
    //Prevent page reload
    event.preventDefault();
    var { first_name, last_name, email, title } = document.forms[0];
    // Find user login info
    const userParams = {
      firstName: first_name.value,
      lastName: last_name.value,
      email: email.value,
      title: title.value
    }
    createUser(userParams, setUser);
  };
  const viewForm = (event) => {
    switch (currentView) {
      case "signUp":
        return (
          <div className="center-div">
            <form onSubmit={handleSignup}>
              <h2>Sign Up!</h2>
              <fieldset>
                <legend>Create Account</legend>
                <ul>
                  <li>
                    <label htmlFor="name">First Name: </label>
                    <input type="text" id="first_name" name='first_name' required />
                  </li>
                  <li>
                    <label htmlFor="name">Last Name: </label>
                    <input type="text" id="last_name" name='last_name' required />
                  </li>
                  <li>
                    <label htmlFor="email">Email: </label>
                    <input type="email" id="email" name="email" required />
                  </li>
                  <li>
                    <label htmlFor="password">Password: </label>
                    <input type="password" id="password" name="password" required />
                  </li>
                  <li>
                    <label htmlFor="password">Title: </label>
                    <input type="text" id="title" name="title" required />
                  </li>
                </ul>
              </fieldset>
              <button type="submit">Submit</button>
              <button type="button" onClick={() => setCurrentView("logIn")}>Have an Account?</button>
            </form>
          </div>
        )
      case "logIn":
        return (
          <div className="center-div">
            <form onSubmit={handleLogin}>
              <h2>Welcome Back!</h2>
              <fieldset>
                <legend>Log In</legend>
                <ul>
                  <li>
                    <label htmlFor="email">Email: </label>
                    <input type="text" id="email" name="email" required />
                  </li>
                  <li>
                    <label htmlFor="password">Password: </label>
                    <input type="password" id="password" name="password" required />
                  </li>
                </ul>
              </fieldset>
              <button type="submit">Submit</button>
              <button type="button" onClick={() => setCurrentView("signUp")}>Create an Account</button>
            </form>
          </div>
        )
      default:
        break
    }
  }
  return (
    <section id="log-in">
      {viewForm()}
    </section>
  )
}
export default LoginScreen;
