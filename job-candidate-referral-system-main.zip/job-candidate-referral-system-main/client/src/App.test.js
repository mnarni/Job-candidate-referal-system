import React from "react";
import {render, screen} from '@testing-library/react';
import '@testing-library/jest-dom';
import App from './App';

test('renders listings link', () => {
  render(<App />);
  const linkElement = screen.getByText(/listings/i);
  expect(linkElement).toBeInTheDocument();
});
