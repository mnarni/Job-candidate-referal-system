import {Link} from "react-router-dom";
import {dataAvailable, extractData, formatDate, makeFullName, makeUrl} from "../api";
import {useFetch} from "../hooks/UseFetch";

const ApplicationsList = ({applications}) => {
    const extractLink = (app, keyword) => app.links.find(link => link.rel === keyword);
    const extractId = linkRef => {
        const stringified = JSON.stringify(linkRef.href).split("/");
        return stringified[stringified.length - 1].replace("\"", "");
    }

    const recruiters = useFetch(makeUrl("/recruiters"));
    const candidates = useFetch(makeUrl("/candidates"));
    const jobs = useFetch(makeUrl("/jobs/all"));

    return (
        <>
            {
                (!dataAvailable(jobs) || !dataAvailable(candidates) || !dataAvailable(recruiters)) ?
                    <p>Loading...</p>
                    :
                    applications.map((app, i) => {
                        const selfLink = extractLink(app, "self");
                        const appDate = formatDate(app.createdAt);

                        // IDs
                        const candidateId = parseInt(extractId(extractLink(app, "candidate")));
                        const recruiterId = parseInt(extractId(extractLink(app, "recruiter")));
                        const jobId = parseInt(extractId(extractLink(app, "job")));

                        // The real deal
                        const job = extractData(jobs).find(job => job.jid === jobId);
                        const candidate = extractData(candidates).find(candidate => candidate.id === candidateId);
                        const recruiter = extractData(recruiters).find(recruiter => recruiter.recruiterId === recruiterId);

                        //  <Link to={'/details'} state={stateObj}>Learn More</Link>
                        // Details page data bundle
                        const applicationInfo = {
                            job,
                            candidate,
                            recruiter,
                            appDate
                        }

                        return (
                            <Link to={`/applications/${selfLink.href.split("/").pop()}`} state={applicationInfo}
                                  key={i}>
                                <div id="app-card" className="card w-85">
                                    <div className="card-body">
                                        <p className="card-title text-dark"
                                           style={{fontSize: "1.6rem"}}>[{job.level}] {job.title}</p>
                                        <p className="text-dark">Candidate: {makeFullName(candidate)} ({candidate.email})</p>
                                        <p className="card-subtitle text-dark">Recruiter: {makeFullName(recruiter)} ({recruiter.email})</p>
                                        <p>------------</p>
                                        <p className={"text-secondary"}>Submitted on {appDate}</p>
                                    </div>
                                </div>
                            </Link>
                        )
                    })
            }
        </>
    );
}

export default ApplicationsList;

