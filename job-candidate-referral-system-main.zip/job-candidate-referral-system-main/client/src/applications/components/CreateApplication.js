import axios from "axios";
import {useState} from "react";
import {useFetch} from "../hooks/UseFetch";
import "bootstrap/dist/css/bootstrap.min.css"
import moment from "moment";
import {
    extractData,
    extractFv,
    getCandidateNames,
    getJobNames,
    getRecruiterNames,
    makeFullName,
    makeUrl,
    populateOptions
} from "../api";
import {useNavigate} from "react-router-dom";

const CreateApplication = () => {
    const navigate = useNavigate();
    const [showFeedback, setShowFeedback] = useState(false)
    const [recruiterFullName, setRecruiterFullName] = useState('');
    const [candidateFullName, setCandidateFullName] = useState('');
    const [jobTitle, setJobTitle] = useState('');
    const [job, setJob] = useState('');
    // TODO: Should this be entered or fetched from existing ones in DB?
    const [candidate, setCandidate] = useState('');
    // TODO: Needed? recruiter ID can be found from a job instance (above)
    const [recruiter, setRecruiter] = useState('');

    const recruiters = useFetch(makeUrl("/recruiters"));
    const recruiterNames = getRecruiterNames(recruiters);
    const candidates = useFetch(makeUrl("/candidates"));
    const candidateNames = getCandidateNames(candidates);
    const jobs = useFetch(makeUrl("/jobs/all"));
    const jobNames = getJobNames(jobs);

    const backToApplicationListing = () => navigate("/applications");

    const createApplication = async e => {
        e.preventDefault();

        const currentTimestamp = moment().format("yyyy-MM-DDThh:mm:ss.SSS")
        const data = {
            jobId: job.jid,
            candidateId: candidate.id,
            recruiterId: recruiter.recruiterId,
            createdAt: currentTimestamp,
            updatedAt: currentTimestamp
        };

        await axios.post(makeUrl("/applications"), data);
        // reset fields
        setJobTitle('');
        setCandidateFullName('');
        setRecruiterFullName('');
        setShowFeedback(true);

    }

    return (
        <div id="create-app-form" className={"container-fluid"}>
            <h3>Apply for a job</h3>
            {showFeedback ? <span className={"center-div bg-success feedback"}>Your application has been successfully submitted</span> : null}
            <form className="col-6 center-div">
                <div className="input-group mb-3">
                    <label className="input-group-text" htmlFor="jobSelection">Position</label>
                    <select
                        id="jobSelection"
                        name="job"
                        value={jobTitle}
                        className="form-select"
                        aria-label="Available jobs (selection)"
                        onChange={e => {
                            const foundJob = extractData(jobs).find(job => {
                                setJobTitle(job.title);
                                return job.title === extractFv(e);
                            });
                            setJob(foundJob);
                        }}
                    >
                        {populateOptions(jobNames)}
                    </select>
                </div>

                <div className="input-group mb-3">
                    <label className="input-group-text" htmlFor="candidateSelection">Candidate</label>
                    <select
                        id="candidateSelection"
                        name="candidate"
                        value={candidateFullName}
                        className="form-select"
                        aria-label="Candidates (selection)"
                        onChange={e => {
                            const foundCandidate = extractData(candidates).find(candidate => {
                                const candidateName = makeFullName(candidate);
                                setCandidateFullName(candidateName);
                                return candidateName === extractFv(e);
                            });
                            setCandidate(foundCandidate);
                        }}
                    >
                        {populateOptions(candidateNames)}
                    </select>
                </div>

                <div className="input-group mb-3">
                    <label className="input-group-text" htmlFor="recruiterSelection">Recruiter</label>
                    <select
                        id="recruiterSelection"
                        name="recruiter"
                        value={recruiterFullName}
                        className="form-select"
                        aria-label="Recruiters (selection)"
                        onChange={e => {
                            const foundRecruiter = recruiters && recruiters.data.find(recruiter => {
                                const recruiterName = makeFullName(recruiter);
                                setRecruiterFullName(recruiterName);
                                return recruiterName === extractFv(e);
                            });
                            setRecruiter(foundRecruiter);
                        }}
                    >
                        {populateOptions(recruiterNames)}
                    </select>
                </div>

                {(!jobTitle || !candidateFullName || !recruiterFullName) ?
                    <button type="submit" className="btn btn-secondary" disabled="disabled">Submit Application</button>
                    :
                    <button type="submit" className="btn btn-success" onClick={createApplication}>Submit
                        Application</button>
                }

                <button style={{marginLeft: "5%"}} type="submit" className="btn btn-danger"
                        onClick={backToApplicationListing}>Cancel
                </button>
            </form>
        </div>
    );
}

export default CreateApplication;

