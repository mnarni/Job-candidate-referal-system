import React from "react";
import '../../index.css';

export default function Application() {
    return (
        <h1>JCRS Home page</h1>
    );
}