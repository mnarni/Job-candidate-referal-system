import apps from "./assets/static-data/job-app-data-multiple.json";
import app from "./assets/static-data/job-app-data-single.json";

const appCount = apps.length;

const candidateLink = JSON.stringify(app._links.candidate);

test("Number of job applications on file", () => {
  expect(appCount).toBe(4);
});

test("Job application has a candidate", () => {
  expect(candidateLink).toContain("/api/candidates/");
});

