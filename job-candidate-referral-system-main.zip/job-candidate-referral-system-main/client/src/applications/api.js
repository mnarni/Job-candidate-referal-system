import moment from "moment";

const BASE_URL = "http://localhost:8008/api";

const makeUrl = part => BASE_URL + part;
const formatDate = date => moment(date).format("MM/DD/yyyy");
const addCommonOption = options => options.unshift("-- Select --"); // common option
const dataAvailable = data => !data.loading && !data.error && data;
const extractData = obj => obj.data;

const getRecruiterNames = recruiters => {
    let recruiterNames;
    if (dataAvailable(recruiters)) {
        // console.log("recruiters");
        // console.log(recruiters);
        recruiterNames = extractData(recruiters).map(recruiter => makeFullName(recruiter))
        addCommonOption(recruiterNames);
        // console.log("recruiter names: ")
        // console.log(recruiterNames)
    }
    return recruiterNames;
}

const getCandidateNames = candidates => {
    let candidateNames;
    if (dataAvailable(candidates)) {
        candidateNames = extractData(candidates).map(candidate => makeFullName(candidate))
        addCommonOption(candidateNames);
    }
    return candidateNames;
}

const getJobNames = jobs => {
    let jobNames;
    if (dataAvailable(jobs)) {
        jobNames = extractData(jobs).map(job => job.title)
        addCommonOption(jobNames);
    }
    return jobNames;
}

const extractJob = (jobs, e) => {
    return extractData(jobs).find(job => job.title === extractFv(e));
}

// Extract field value
const extractFv = e => {
    return e.target.value;
}

const makeFullName = entity => {
    return entity.firstName + " " + entity.lastName;
}

const populateOptions = values => {
    return values && values.map(currentValue => <option key={currentValue} value={currentValue}>{currentValue}</option>);
}

export {
    makeUrl,
    formatDate,
    getRecruiterNames,
    getCandidateNames,
    getJobNames,
    extractJob,
    populateOptions,
    makeFullName,
    extractFv,
    extractData,
    dataAvailable
};

