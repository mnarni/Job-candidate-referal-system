import {useLocation, useNavigate, useParams} from "react-router-dom";
import {formatDate, makeFullName, makeUrl} from "../api";
import axios from "axios";

const ApplicationSingle = () => {
    const {state} = useLocation();
    const navigate = useNavigate();
    const {appId} = useParams();

    const {job, candidate, recruiter, appDate} = state;

    const backToApplicationListing = () => navigate("/applications");

    const deleteApp = async e => {
        e.preventDefault();

        await axios.delete(makeUrl(`/applications/${appId}`))
            .then(res => navigate("/applications/delete/success"));
    }

    return (
        <>
            <div className="card w-85" style={{borderBottom: "none"}}>
                <div className="card-body">
                    <p className="card-title text-dark" style={{fontSize: "1.6rem"}}>{job.title}</p>
                    <p className="text-black-50"><em>Job level</em>: {job.level}</p>
                    <p className="text-black-50">{job.description}</p>
                    <p className={"text-muted font-monospace"}>Posted on {formatDate(job.createdAt)}</p>
                    <p className={"text-danger"}>------------------------</p>
                    <p className="text-dark">Candidate: {makeFullName(candidate)} <span
                        className={"text-danger"}>&rarr;</span> {candidate.email}</p>
                    <p className="card-subtitle text-dark">Recruiter: {makeFullName(recruiter)} <span
                        className={"text-danger"}>&rarr;</span> {recruiter.email}</p>
                    <p className={"text-success"}>------------------------</p>
                    <p className={"text-muted"}>Application submitted on {appDate}</p>
                </div>
                <div id="app-action-buttons">
                    <button type="submit" className="btn btn-success col-2" style={{marginLeft: "3%", float: "left"}}
                            onClick={backToApplicationListing}>&larr; All applications
                    </button>
                    <button type="submit" className="btn btn-danger col-1" style={{marginLeft: "3%", float: "left"}}
                            onClick={deleteApp}> Delete
                    </button>
                </div>
            </div>
        </>
    );
}

export default ApplicationSingle;

