import {useNavigate} from "react-router-dom";

const ApplicationSingle = () => {
    const navigate = useNavigate();

    const backToApplicationListing = () => navigate("/applications");

    return (
        <div className="card w-85" style={{borderBottom: "none"}}>
            <div className="card-body">
                <p className={"text-dark font-monospace alert alert-success col-6"}>Application deleted successfully</p>
            </div>
            <div id="app-action-buttons">
                <button type="submit" className="btn btn-success col-1" style={{marginLeft: "3.5%", float: "left"}}
                        onClick={backToApplicationListing}>&larr; All applications
                </button>
            </div>
        </div>
    );
}

export default ApplicationSingle;

