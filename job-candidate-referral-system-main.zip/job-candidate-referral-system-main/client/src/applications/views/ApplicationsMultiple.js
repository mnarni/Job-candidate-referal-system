import ApplicationsList from "../components/ApplicationsList";
import {useFetch} from "../hooks/UseFetch";
import {makeUrl} from "../api";

const ApplicationsMultiple = () => {
    const {loading, data, error} = useFetch(makeUrl("/applications"));

    if (loading) {
        return (<h1>Loading...</h1>);
    }

    if (error) {
        return (<pre>{JSON.stringify(error, null, 2)}</pre>);
    }

    return (
        <>
            <h1>Submitted job applications</h1>
            <div className={"container-fluid col-8 center-div"}>
                <ApplicationsList applications={data}/>
            </div>
        </>
    );
}

export default ApplicationsMultiple;

