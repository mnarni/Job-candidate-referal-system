const Placeholder = () => {
    return (
        <h1>This is a placeholder page</h1>
    );
}

export default Placeholder;

