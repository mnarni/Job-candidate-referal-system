import React from "react";
import C from "./Constants";

const HomePage = () => {
    const altTxt = C.APP_NAME + " home page";
    return (
        <>
            <div className="jumbotron jumbotron-fluid">
                <div className="container">
                    <h1 className="display-4">{C.APP_NAME}</h1>
                    <img src="./images/jcrs-home.jpg" alt={altTxt}
                         className="img-fluid" style={{height: "80%"}}/>
                    <p className="lead center-div">
                        Let that next candidate find the dream job
                    </p>
                </div>
            </div>
            <div className="card center-div" style={{width: "100%", border: "none"}}>
                <div className="card-body">
                    <h4 className="card-title">How it works</h4>
                    <div className="alert alert-success" style={{border: "none"}}></div>
                    <div className="container-fluid center-justified" style={{textAlign: "justify", margin: "0 auto", width: "40em"}}>
                        <h5 className="card-subtitle mb-2 text-body-secondary">&#x2713; You (an employee) find a job in the <a href="http://localhost:3008/jobsportal"> listings</a></h5>
                        <h5 className="card-subtitle mb-2 text-body-secondary">&#x2713; Click <strong>Recommend Position</strong></h5>
                        <h5 className="card-subtitle mb-2 text-body-secondary">&#x2713; Enter basic information about the candidate</h5>
                        <h5 className="card-subtitle mb-2 text-body-secondary">&#x2713; J.C.R.S sends out an email to the candidate with a link to apply</h5>
                        <h5 className="card-subtitle mb-2 text-body-secondary">&#x2713; The candidate <a href="http://localhost:3008/applications/create"><strong>applies</strong> via that link</a></h5>
                        <h5 className="card-subtitle mb-2 text-body-secondary">&#x2713; Once they get hired, you get a fat referral bonus check</h5>
                        <h5 className="card-subtitle mb-2 text-body-secondary">&#x2713; Rinse and repeat! No limit to the bonuses</h5>
                    </div>
                </div>
            </div>
        </>
    );
}

export default HomePage;

