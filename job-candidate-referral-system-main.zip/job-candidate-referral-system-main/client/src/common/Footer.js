import React from "react";
import C from "./Constants";

export default function Footer() {
    return (
        <div className="container-fluid">
            <nav className="navbar navbar-expand-lg navbar-light bg-success bg-opacity-10" style={{paddingTop: "60px", marginTop: "100px", marginBottom: 0}}>
                &nbsp;&nbsp;
                {C.APP_NAME} ({C.APP_ACRONYM}) &copy; {(new Date()).getFullYear()}
                &nbsp;&nbsp;&nbsp;&nbsp;
                Daniel Dut
                &nbsp;<span className="text-danger fw-bolder">|</span>&nbsp;
                Jayden Godbold
                &nbsp;<span className="text-danger fw-bolder">|</span>&nbsp;
                Monica Narni
                &nbsp;<span className="text-danger fw-bolder">|</span>&nbsp;
                Marcel Alfonso Garcia
                &nbsp;&nbsp;/&nbsp;&nbsp;
                All rights reserved.
            </nav>
        </div>
    );
}

