const Constants = {
    APP_NAME: "Job Candidate Referral System",
    APP_ACRONYM: "J.C.R.S"
};

export default Constants;