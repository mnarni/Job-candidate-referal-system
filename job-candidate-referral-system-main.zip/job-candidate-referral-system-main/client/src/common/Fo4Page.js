const Fo4Page = () => <h1>404: Page not found!</h1>;

export default Fo4Page;