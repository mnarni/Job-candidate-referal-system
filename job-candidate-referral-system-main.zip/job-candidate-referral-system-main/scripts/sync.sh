#!/usr/bin/env bash

# To run: $ scripts/sync.sh <branch_name>
m='main'
target_branch=$1

if [[ "$target_branch" != "" ]]; then
  echo -e "\n   Syncing '$target_branch' branch with the '$m' branch\n"

  git checkout "$m"
  git pull origin "$m"
  git checkout "$target_branch"
  git merge --no-edit "$m"
  git push origin "$target_branch"
else
  echo -e "\n   Please enter a branch to sync with '$m'!\n"
fi
