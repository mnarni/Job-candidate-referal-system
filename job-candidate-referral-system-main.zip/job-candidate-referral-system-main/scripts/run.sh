#!/usr/bin/env bash

app_name="Job Candidate Referral System"
port=8008

# Making it path-resilient
project_root=$(echo $app_name | tr '[:upper:]' '[:lower:]' | sed 's/ /-/g') # lowercase app name and replace spaces with hyphens
current_dir=$(pwd)
path_array=($(echo "$current_dir" | tr '/' '\n'))
last_part=${path_array[-1]}
path_before_root=$(echo "$current_dir" | sed 's/job.*//')

if [[ "$last_part" != "$project_root" ]]; then
    # We are NOT at the root, going to the root
    cd "${path_before_root}${project_root}" || return
fi

echo -e "\n\t '$app_name' running on http://localhost:$port\n"
echo -e "\tDatabase available at http://localhost:$port/h2-console\n"
echo -e "\tREST API endpoints available at http://localhost:$port/api/<last_part>"
echo -e "\tSample REST API endpoint: http://localhost:$port/api/applications\n"
echo -e "\tTo stop the app, press 'Ctrl + C' on your keyboard.\n"

# Move into the appropriate dir
cd server

# Build and run
./gradlew build
./gradlew bootRun

# TODO: Run the client in a different terminal here?
