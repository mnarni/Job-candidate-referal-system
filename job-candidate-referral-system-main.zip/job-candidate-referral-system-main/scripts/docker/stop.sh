#!/usr/bin/env bash

app_name="Job Candidate Referral System"
app_alias=jcrs

docker stop "$(docker ps -q --filter ancestor=$app_alias)" | xargs docker rm

echo -e "\n\tBye... 😒 '$app_name' stopped!\n"
