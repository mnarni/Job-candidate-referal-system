
#!/usr/bin/env bash

app_name="Job Candidate Referral System"
app_alias=jcrs
port=8008

docker build -t $app_alias .
docker run -p $port:$port -d $app_alias

echo -e "\n\t'$app_name' running on http://localhost:$port\n"
echo -e "\tDatabase available at http://localhost:$port/h2-console\n"
echo -e "\tTo stop the app, run: './scripts/stop.sh'\n"