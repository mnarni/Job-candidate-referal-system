## Screenshots of running code

### Running App in the Console
![Running App in the Console](img/console.png)

<br>

### Sample Endpoint call in browser
![Sample Endpoint call in browser](img/browser.png)
