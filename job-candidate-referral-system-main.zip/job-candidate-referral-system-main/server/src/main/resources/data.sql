--Jayden--
--applicants--
INSERT INTO applicant(name, email)
VALUES ('Marcus Roberts', 'mroberts@gmail.com');
INSERT INTO applicant(name, email)
VALUES ('Bryant White', 'BRYFRY1@gmail.com');
INSERT INTO applicant(name, email)
VALUES ('Joseph Khory', 'lilkhory5@gmail.com');
INSERT INTO applicant(name, email)
VALUES ('Marcus Roberts', 'mroberts@gmail.com');



-- Employees --
INSERT INTO employee(first_name, last_name, email, title)
VALUES ('Marcel', 'Alfonso', 'malfons1@depaul.edu', 'Manager');
INSERT INTO employee(first_name, last_name, email, title)
VALUES ('Daniel', 'Dut', 'ddut@depaul.edu', 'Manager');
INSERT INTO employee(first_name, last_name, email, title)
VALUES ('Monica', 'Narni', 'mnarni@depaul.edu', 'Engineer');
INSERT INTO employee(first_name, last_name, email, title)
VALUES ('Jayden', 'Godbold', 'godbold.j301@gmail.com', 'Engineer');

-- Recruiters --
INSERT INTO recruiter(first_name, last_name, email)
VALUES ('Jade', 'Wire', 'jwire@jcrs.com');
INSERT INTO recruiter(first_name, last_name, email)
VALUES ('Andy', 'Android', 'aandroid@jcrs.com');
INSERT INTO recruiter(first_name, last_name, email)
VALUES ('Bill', 'Doe', 'bdoe@jcrs.com');

-- TODO: Can credentials, previous jobs, referees be inserted separately with candidate IDs?
-- Candidates --
INSERT INTO candidate(first_name, last_name, email, referrer_id, credential_id, previous_job_id, referee_id, military_affiliated)
VALUES ('Dut', 'A', 'dut-a@jcrs.com', 3, 1, 2, 1, 0);
INSERT INTO candidate(first_name, last_name, email, referrer_id, credential_id, previous_job_id, referee_id, military_affiliated)
VALUES ('Bol', 'Manut', 'bol-m@jcrs.com', 1, 2, 1, 2, 1);
INSERT INTO candidate(first_name, last_name, email, referrer_id, credential_id, previous_job_id, referee_id, military_affiliated)
VALUES ('Malual', 'M', 'malual-m@jcrs.com', 3, 1, 2, 1, 0);
INSERT INTO candidate(first_name, last_name, email, referrer_id, credential_id, previous_job_id, referee_id, military_affiliated)
VALUES ('Bol','B','bol-b@jcrs.com',3,1,2,1,0);

-- Job openings --
INSERT INTO job(recruiter_id, title, level, description, openings, filled)
VALUES (2, 'Software Engineer I', 'Associate', 'Software Engineer with at least 3 years experience', 3, 'Y');
INSERT INTO job(recruiter_id, title, level, description, openings, filled)
VALUES (1, 'Software Engineer II', 'Senior Associate', 'Software Engineer with at least 5 years experience', 2, 'N');

-- Schools --
INSERT INTO school(name, address, candidate_id)
VALUES ('DePaul University', '243 S Wabash Ave, Chicago, IL 60604', 1);
INSERT INTO school(name, address, candidate_id)
VALUES ('Loyola University Chicago', '1032 W Sheridan Rd, Chicago, IL 60660', 2);

-- Credentials --
INSERT INTO credential(candidate_id, school_id, years_completed, graduated, credential_type)
VALUES (1, 1, 2, 1, 'Certificate');
INSERT INTO credential(candidate_id, school_id, years_completed, graduated, credential_type)
VALUES (2, 1, 4, 1, 'Bachelor''s Degree');
INSERT INTO credential(candidate_id, school_id, years_completed, graduated, credential_type)
VALUES (2, 2, 2, 1, 'Master''s Degree');

-- Previous jobs --
INSERT INTO previous_job(candidate_id, title, level, description)
VALUES (1, 'Software Engineer', 'Associate', 'Backend Engineer (Java)');
INSERT INTO previous_job(candidate_id, title, level, description)
VALUES (2, 'Software Engineer', 'Principal', 'Backend Engineer (Python)');
INSERT INTO previous_job(candidate_id, title, level, description)
VALUES (2, 'Software Engineer', 'Junior', 'Backend Engineer (PHP)');

-- Referees --
INSERT INTO referee(candidate_id, first_name, last_name)
VALUES (1, 'William', 'Wine');
INSERT INTO referee(candidate_id, first_name, last_name)
VALUES (2, 'Joseph', 'Dine');
INSERT INTO referee(candidate_id, first_name, last_name)
VALUES (1, 'Digla', 'Udom');

-- Applications --
INSERT INTO job_application(job_id, candidate_id, recruiter_id)
VALUES (1, 1, 1);
INSERT INTO job_application(job_id, candidate_id, recruiter_id)
VALUES (2, 2, 2);
INSERT INTO job_application(job_id, candidate_id, recruiter_id)
VALUES (2, 3, 2);
INSERT INTO job_application(job_id, candidate_id, recruiter_id)
VALUES (2, 4, 2);
INSERT INTO job_application(job_id, candidate_id, recruiter_id)
VALUES (1, 1, 1);
INSERT INTO job_application(job_id, candidate_id, recruiter_id)
VALUES (1, 2, 1);
INSERT INTO job_application(job_id, candidate_id, recruiter_id)
VALUES (2, 3, 2);
INSERT INTO job_application(job_id, candidate_id, recruiter_id)
VALUES (2, 4, 2);

