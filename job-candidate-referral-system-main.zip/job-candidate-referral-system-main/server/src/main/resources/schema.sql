DROP TABLE IF EXISTS applicant; --Jayden--
DROP TABLE IF EXISTS employee;
DROP TABLE IF EXISTS candidate;
DROP TABLE IF EXISTS recruiter;
DROP TABLE IF EXISTS job;
DROP TABLE IF EXISTS school;
DROP TABLE IF EXISTS credential;
DROP TABLE IF EXISTS previous_job;
DROP TABLE IF EXISTS referee;
DROP TABLE IF EXISTS job_application;


CREATE SEQUENCE hibernate_sequence START WITH 100 INCREMENT BY 1;

--Jayden--
CREATE TABLE applicant
(
    aid        BIGINT AUTO_INCREMENT NOT NULL PRIMARY KEY,
    name       VARCHAR(50)           NOT NULL,
    email      VARCHAR(50)           NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    PRIMARY KEY (aid)
);

CREATE TABLE employee
(
    eid        INTEGER AUTO_INCREMENT NOT NULL,
    first_name VARCHAR(50)            NOT NULL,
    last_name  VARCHAR(50)            NOT NULL,
    email      VARCHAR(50)            NOT NULL,
    title      VARCHAR(20)            NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    PRIMARY KEY (eid)
);

CREATE TABLE recruiter
(
    rid          INT AUTO_INCREMENT PRIMARY KEY,
    first_name   VARCHAR(80) NOT NULL,
    last_name    VARCHAR(80) NOT NULL,
    email        TEXT,
    phone_number VARCHAR(15),
    created_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE job
(
    jid          INTEGER AUTO_INCREMENT NOT NULL,
    recruiter_id INTEGER                NOT NULL,
    title        VARCHAR(50)            NOT NULL,
    level        VARCHAR(50)            NOT NULL,
    description  VARCHAR(200)           NOT NULL,
    requirements VARCHAR(500),
    openings     INTEGER                NOT NULL,
    filled       VARCHAR(1)             NOT NULL,
    created_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    PRIMARY KEY (jid),
    FOREIGN KEY (recruiter_id) REFERENCES recruiter (rid)
);

-- BEGIN: feature -> Applications --
CREATE TABLE candidate
(
    id                  INT AUTO_INCREMENT PRIMARY KEY,
    first_name          VARCHAR(80) NOT NULL,
    last_name           VARCHAR(80) NOT NULL,
    email               TEXT        NOT NULL,
    referrer_id         BIGINT      NOT NULL,
    credential_id       BIGINT      ,
    previous_job_id     BIGINT      ,
    referee_id          BIGINT      ,
    military_affiliated TINYINT     NOT NULL DEFAULT 0,
    created_at          TIMESTAMP            DEFAULT CURRENT_TIMESTAMP,
    updated_at          TIMESTAMP            DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE school
(
    school_id    BIGINT AUTO_INCREMENT NOT NULL PRIMARY KEY,
    name         VARCHAR(300)          NOT NULL,
    address      VARCHAR(500)          NOT NULL, -- TODO: extract this to a table?
    email        TEXT,
    phone_number VARCHAR(15),
    candidate_id BIGINT                NOT NULL,
    created_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (candidate_id) REFERENCES candidate (id)
);

CREATE TABLE credential
(
    id              BIGINT AUTO_INCREMENT NOT NULL PRIMARY KEY,
    candidate_id    BIGINT                NOT NULL,
    school_id       BIGINT                NOT NULL,
    years_completed INT                   NOT NULL, -- 2.5? 4?
    graduated       TINYINT               NOT NULL, -- Yes/No
    major           VARCHAR(200),                   -- History/Computer Science/Sociology
    credential_type VARCHAR(100)          NOT NULL, -- Certificate/Diploma/Degree
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (candidate_id) REFERENCES candidate (id),
    FOREIGN KEY (school_id) REFERENCES school (school_id)
);

CREATE TABLE previous_job
(
    id           BIGINT AUTO_INCREMENT NOT NULL PRIMARY KEY,
    candidate_id BIGINT                NOT NULL,
    title        VARCHAR(50)           NOT NULL,
    level        VARCHAR(50)           NOT NULL,
    description  VARCHAR(200)          NOT NULL,
    created_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (candidate_id) REFERENCES candidate (id)
);

CREATE TABLE referee
(
    id                BIGINT AUTO_INCREMENT NOT NULL PRIMARY KEY,
    candidate_id      BIGINT                NOT NULL,
    first_name        VARCHAR(80)           NOT NULL,
    last_name         VARCHAR(80)           NOT NULL,
    email             TEXT,
    phone_number      VARCHAR(15),
    preferred_contact VARCHAR(20), -- email? phone? any?
    created_at        TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at        TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (candidate_id) REFERENCES candidate (id)
);

CREATE TABLE job_application
(
    id           BIGINT AUTO_INCREMENT NOT NULL PRIMARY KEY,
    job_id       BIGINT                NOT NULL,
    candidate_id BIGINT                NOT NULL,
    recruiter_id BIGINT                NOT NULL,
    created_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (job_id) REFERENCES job (jid),
    FOREIGN KEY (candidate_id) REFERENCES candidate (id),
    FOREIGN KEY (recruiter_id) REFERENCES recruiter (rid)
);

-- END: feature -> Applications --

