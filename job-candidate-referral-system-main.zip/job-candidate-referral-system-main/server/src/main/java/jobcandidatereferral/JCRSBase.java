package jobcandidatereferral;

import org.springframework.hateoas.MediaTypes;
import org.springframework.http.MediaType;

public class JCRSBase {
    public static final String API_VERSION = "1.0.0";
    public static final String API_BASE_URL = "http://localhost:8008/api";
    public static final String APP_NAME = "Job Candidate Referral System";
    public static final String WIKI_PAGE = "https://github.com/dut-a/job-candidate-referral-system/blob/main/wiki.html";
    public static final String LICENCE = "Apache 2.0";
    public static final String LICENCE_URL = "https://www.apache.org/licenses/LICENSE-2.0";

    // Media types
    public static final String JSON = MediaType.APPLICATION_JSON_VALUE;
    public static final String HAL_JSON = MediaTypes.HAL_JSON_VALUE;

    // [Spring] Profiles
    public static class Profiles {
        public static final String DEV = "dev";
        public static final String TEST = "test";
        public static final String QA = "qa";
        public static final String PROD = "prod";
    }

    private JCRSBase() {}
}

