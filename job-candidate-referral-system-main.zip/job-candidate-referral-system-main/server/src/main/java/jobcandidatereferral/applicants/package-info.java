
/**
 * <h1 style="text-decoration: underline;">Documentation for the 'Applicants' portion of this system</h1>
 * @author Jayden
 */
package jobcandidatereferral.applicants;

