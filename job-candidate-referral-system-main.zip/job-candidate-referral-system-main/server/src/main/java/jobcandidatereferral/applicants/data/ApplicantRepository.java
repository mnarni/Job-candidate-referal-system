package jobcandidatereferral.applicants.data;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import jobcandidatereferral.applicants.data.ApplicantRepository;
import jobcandidatereferral.applicants.model.Applicant;

@Repository
public interface ApplicantRepository extends JpaRepository<Applicant, Long> {
}
