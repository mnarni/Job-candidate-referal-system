package jobcandidatereferral.applicants.mapper;

import jobcandidatereferral.applicants.model.Applicant;
import jobcandidatereferral.applications.model.Candidate;

public class ApplicantMapper {

    public Applicant candidateToApplicantMapper(Candidate c) {
        return new Applicant(c.getFirstName() + " " + c.getLastName(), c.getEmail());
    }

}
