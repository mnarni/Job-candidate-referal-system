package jobcandidatereferral.applicants.service;
import jobcandidatereferral.applicants.model.Applicant;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class ApplicantService {

    private final List<Applicant> applicants = new ArrayList<>();
    private long nextApplicantId = 1;

    public List<Applicant> getAllApplicants() {
        return applicants;
    }

    public Applicant getApplicantById(Long aid) {
        for (Applicant applicant : applicants) {
            if (applicant.getId().equals(aid)) {
                return applicant;
            }
        }
        return null;
    }

    public Applicant createApplicant(Applicant applicant) {
        applicant.setId(nextApplicantId++);
        applicants.add(applicant);
        return applicant;
    }

    public Applicant updateApplicant(Long aid, Applicant updatedApplicant) {
        for (int i = 0; i < applicants.size(); i++) {
            Applicant applicant = applicants.get(i);
            if (applicant.getId().equals(aid)) {
                updatedApplicant.setId(aid);
                applicants.set(i, updatedApplicant);
                return updatedApplicant;
            }
        }
        return null;
    }

    public boolean deleteApplicant(Long aid) {
        for (Applicant applicant : applicants) {
            if (applicant.getId().equals(aid)) {
                applicants.remove(applicant);
                return true;
            }
        }
        return false;
    }
}