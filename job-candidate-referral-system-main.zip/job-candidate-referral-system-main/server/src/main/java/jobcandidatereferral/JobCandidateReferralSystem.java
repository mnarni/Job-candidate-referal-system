package jobcandidatereferral;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JobCandidateReferralSystem {

	public static void main(String[] args) {
		SpringApplication.run(JobCandidateReferralSystem.class, args);
	}

}
