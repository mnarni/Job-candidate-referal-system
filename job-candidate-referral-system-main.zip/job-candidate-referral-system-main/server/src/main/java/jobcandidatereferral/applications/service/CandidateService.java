package jobcandidatereferral.applications.service;

import jobcandidatereferral.applications.data.CandidateRepository;
import jobcandidatereferral.applications.model.Candidate;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Slf4j
@Service
@RequiredArgsConstructor
public class CandidateService {
    private final CandidateRepository repository;

    public Candidate create(Candidate candidate) {
        LOG.info("Saving a candidate to the DB");
        return repository.save(candidate);
    }

    public List<Candidate> getAll() {
        LOG.info("Fetching all candidates");
        return repository.findAll();
    }

    public Optional<Candidate> getOne(Long id) {
        LOG.info("Trying to fetch a candidate with the following ID: {}", id);
        return repository.findById(id);
    }

    public Candidate update(Candidate candidate, Long id) {
        LOG.info("Updating a candidate with the following ID: {}", id);
        return repository.findById(id)
                .map(c -> {
                    var foundCandidate = c.toBuilder()
                            .firstName(candidate.getFirstName())
                            .lastName(candidate.getLastName())
                            .email(candidate.getEmail())
                            .referrerId(candidate.getReferrerId())
                            .credentialId(candidate.getCredentialId())
                            .previousJobId(candidate.getPreviousJobId())
                            .refereeId(candidate.getRefereeId())
                            .militaryAffiliated(candidate.isMilitaryAffiliated())
                            .updatedAt(LocalDateTime.now())
                            .build();
                    return repository.save(foundCandidate);
                }).orElseThrow();
    }

    public void delete(Candidate candidate) {
        LOG.info("Deleting a candidate");
        repository.delete(candidate);
    }

    public void delete(Long id) {
        LOG.info("Deleting a candidate with the following ID: {}", id);
        repository.deleteById(id);
    }
}

