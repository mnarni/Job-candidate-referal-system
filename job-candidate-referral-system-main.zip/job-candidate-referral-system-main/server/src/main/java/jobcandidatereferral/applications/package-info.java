/**
 * <h1 style="text-decoration: underline;">Documentation for the 'Applications' portion of this system</h1>
 * <p>This feature allows a candidate recommended to apply for the position they've been recommended for</p>
 * <p>Developer: Daniel Dut</p>
 * <ol>
 *  <li>DB wiring and/or seeding
 *      <ul>
 *          <li>Schema: See <strong>server/src/main/resources/schema.sql (feature -> Applications)</strong></li>
 *          <li>Seeding: See <strong>server/src/main/resources/data.sql</strong></li>
 *      </ul>
 *  </li>
 *  <li>REST Endpoint: <a href="http://localhost:8008/api/applications">http://localhost:8008/api/applications</a></li>
 *  <li>API docs: Available in OpenAPI 3.0 format; access via <a href="http://localhost:8008/swagger-ui/index.html">Swagger UI</a></li>
 *  <li>Unit and Integration Tests: Written in <a href="https://junit.org/junit5/">JUnit 5</a>, <a href="https://assertj.github.io/doc/">AssertJ</a> & <a href="https://site.mockito.org">Mockito</a> (see corresponding work items below)</li>
 * </ol>
 *
 * <hr>
 *
 * <h2>Work items</h2>
 * <h4><strong>Base directory:</strong> job-candidate-referral-system</h4>
 * <h4><strong>Scripts directory:</strong> /scripts</h4>
 * <h2><span style="text-decoration: underline;">Backend</span></h2>
 * <h4><strong>Feature package:</strong> /server/src/main/java/jobcandidatereferral/applications</h4>
 * <img src="../../../resources/static/applications/backend-structure.png" alt="Backend code structure" />
 * <ul>
 *     <li>Configured database connection in YAML config files (whole application).</li>
 *     <li>Dockerized the application (scripts directory above).</li>
 *     <li>Configured CI/CD pipeline via Github Actions (whole application).</li>
 *     <li>Put together bash scripts for operating the application (scripts directory above).</li>
 *     <li>Wrote all Applications feature CRUD.</li>
 *     <li>HATEOAS support added to the REST endpoints.</li>
 *     <li>
 *         <p>Fully documented REST API endpoints with OpenAPI 3.0</p>
 *         <p>See the following on <a href="http://localhost:8008/swagger-ui/index.html">Swagger UI</a></p>
 *         <ul>
 *             <li><a href="http://localhost:8008/swagger-ui/index.html#/Candidate">Candidate</a></li>
 *             <li><a href="http://localhost:8008/swagger-ui/index.html#/Credential">Credential</a></li>
 *             <li><a href="http://localhost:8008/swagger-ui/index.html#/Job%20application">Job application</a></li>
 *             <li><a href="http://localhost:8008/swagger-ui/index.html#/Previous%20job">Previous job</a></li>
 *             <li><a href="http://localhost:8008/swagger-ui/index.html#/Referee">Referee</a></li>
 *         </ul>
 *     </li>
 *     <li>Configured REST API info class (ApplicationOpenApiConfig) (whole application)</li>
 *     <li>
 *         Tests
 *         <ol>
 *             <li>Wrote unit tests for the service layer<br>(available here: /server/src/test/java/jobcandidatereferral/applications/service)</li>
 *             <li>Wrote integration tests for the web layer (controllers)<br>(available here: /server/src/test/java/jobcandidatereferral/applications/controller)</li>
 *             <li>Wrote integration tests for the data layer (repositories)<br>(available here: /server/src/test/java/jobcandidatereferral/applications/data)</li>
 *         </ol>
 *         <img src="../../../resources/static/applications/unit-integration-tests.png" alt="Unit & Integration tests with code coverage" />
 *     </li>
 * </ul>
 *
 * <p>======</p><br>
 *
 * <h2><span style="text-decoration: underline;">Frontend</span></h2>
 * <h4><strong>Feature package:</strong> /client/src/applications</h4>
 * <img src="../../../resources/static/applications/frontend-structure.png" alt="Frontend code structure" />
 * <ul>
 *     <li>Configured nvm for the application and added instructions for it into the top-level README.</li>
 *     <li>Added the top-level navigation menu for the whole application.</li>
 *     <li>Fixed index.html and manifest.json (/client/public/)</li>
 *     <li>Wrote the base CSS (home.css).</li>
 *     <li>Put together the 404 and home pages.</li>
 *     <li>Wrote all Applications feature CRUD.</li>
 *     <li>Configured and used Bootstrap 5 for most of the frontend styling</li>
 * </ul>
 * <p>
 *
 * <p>************============************</p><br>
 * <hr>
 * <h1 style="text-decoration: underline;">Extra miles</h1>
 * <h2>Non-persistence</h2>
 * <ol>
 *     <li>Configured sensible defaults for application management.</li>
 *     <p>i.e. <strong>management:</strong> key in <strong>server/src/main/resources/application.yml</strong></p>
 *     <li>Integrated application metrics observability with WaveFront <a href="https://wavefront.surf/us/1y9sqJVMyq">JCRS Metrics</a></li>
 *     <p>i.e. <strong>wavefront:</strong> key under <strong>management:</strong> key in <strong>server/src/main/resources/application.yml</strong></p>
 *     <li>Added support for HATEOAS for all endpoints of the <strong>Applications</strong> feature and some end endpoints in other features</li>
 *     <p>See {@link jobcandidatereferral.employees.controller.EmployeeRestController}</p>
 * </ol>
 * <h2>Persistence</h2>
 * <ol>
 *     <li>
 *         Added filtering feature for <strong>Credentials</strong> for a given candidate (fully wired up and exposed as REST endpoint)
 *         <ul>
 *             <li>REST endpoint: {@link jobcandidatereferral.applications.controller.CredentialRestController#getCredentialsForCandidate}</li>
 *             <li>Repository: {@link jobcandidatereferral.applications.service.CredentialService#getCredentialsForCandidate}</li>
 *             <li>Service: {@link jobcandidatereferral.applications.data.CredentialRepository#findCredentialsByCandidateId}</li>
 *         </ul>
 *     </li>
 *     <li>
 *         Added filtering feature for <strong>Previous jobs</strong> for a given candidate (fully wired up and exposed as REST endpoint)
 *         <ul>
 *             <li>REST endpoint: {@link jobcandidatereferral.applications.controller.PreviousJobRestController#getPreviousJobsForCandidate}</li>
 *             <li>Repository: {@link jobcandidatereferral.applications.service.PreviousJobService#getPreviousJobsForCandidate}</li>
 *             <li>Service: {@link jobcandidatereferral.applications.data.PreviousJobRepository#findPreviousJobsByCandidateId}</li>
 *         </ul>
 *     </li>
 *     <li>
 *         Added filtering feature for <strong>Referees</strong> for a given candidate (fully wired up and exposed as REST endpoint)
 *         <ul>
 *             <li>REST endpoint: {@link jobcandidatereferral.applications.controller.RefereeRestController#getRefereesForCandidate}</li>
 *             <li>Repository: {@link jobcandidatereferral.applications.service.RefereeService#getRefereesForCandidate}</li>
 *             <li>Service: {@link jobcandidatereferral.applications.data.RefereeRepository#findRefereesByCandidateId}</li>
 *         </ul>
 *     </li>
 * </ol>
 * <hr>
 * <h1 style="text-decoration: underline;">Extra miles for the TEAM</h1>
 * <ol>
 *     <li>Fixed {@link jobcandidatereferral.employees.service.EmployeeService}</li>
 *     <li>Fixed {@link jobcandidatereferral.employees.controller.EmployeeRestController} and added HATEOAS support to it</li>
 *     <li>Wrote {@link jobcandidatereferral.employees.controller.RecruiterRestController#getAll}</li>
 *     <li>Wrote {@link jobcandidatereferral.employees.controller.RecruiterRestController#getRecruiter}</li>
 *     <li>Wrote {@link jobcandidatereferral.employees.data.RecruiterRepository}</li>
 *     <li>Wrote {@link jobcandidatereferral.employees.model.Recruiter}</li>
 *     <li>Wrote {@link jobcandidatereferral.employees.service.RecruiterService#getAll}</li>
 *     <li>Wrote {@link jobcandidatereferral.employees.service.RecruiterService#getOne}</li>
 * </ol>
 * <hr>
 *
 * @version 1.0
 * @author Daniel Dut
 * @since 0.0.1
 */
package jobcandidatereferral.applications;



