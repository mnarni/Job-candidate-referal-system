package jobcandidatereferral.applications.service;

import jobcandidatereferral.applications.data.RefereeRepository;
import jobcandidatereferral.applications.model.Referee;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Slf4j
@Service
@RequiredArgsConstructor
public class RefereeService {
    private final RefereeRepository repository;

    public Referee create(Referee referee) {
        LOG.info("Saving a referee to the DB");
        return repository.save(referee);
    }

    public List<Referee> getAll() {
        LOG.info("Fetching all referees");
        return repository.findAll();
    }

    public Optional<Referee> getOne(Long id) {
        LOG.info("Trying to fetch a referee with the following ID: {}", id);
        return repository.findById(id);
    }

    public List<Referee> getRefereesForCandidate(Long candidateId) {
        LOG.info("Fetching all referees for a candidate with the following ID: {}", candidateId);
        return repository.findRefereesByCandidateId(candidateId);
    }

    public Referee update(Referee referee, Long id) {
        LOG.info("Updating a referee with the following ID: {}", id);
        return repository.findById(id)
                .map(ref -> {
                    var foundRef = ref.toBuilder()
                            .candidateId(referee.getCandidateId())
                            .firstName(referee.getFirstName())
                            .lastName(referee.getLastName())
                            .email(referee.getEmail())
                            .phoneNumber(referee.getPhoneNumber())
                            .preferredContact(referee.getPreferredContact())
                            .updatedAt(LocalDateTime.now())
                            .build();
                    return repository.save(foundRef);
                }).orElseThrow();
    }

    public void delete(Referee referee) {
        LOG.info("Deleting a referee");
        repository.delete(referee);
    }

    public void delete(Long id) {
        LOG.info("Deleting a referee with the following ID: {}", id);
        repository.deleteById(id);
    }
}

