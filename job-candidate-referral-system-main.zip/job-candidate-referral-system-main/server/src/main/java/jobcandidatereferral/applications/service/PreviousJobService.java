package jobcandidatereferral.applications.service;

import jobcandidatereferral.applications.data.PreviousJobRepository;
import jobcandidatereferral.applications.model.PreviousJob;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Slf4j
@Service
@RequiredArgsConstructor
public class PreviousJobService {
    private final PreviousJobRepository repository;

    public PreviousJob create(PreviousJob previousJob) {
        LOG.info("Saving a previous job to the DB");
        return repository.save(previousJob);
    }

    public List<PreviousJob> getAll() {
        LOG.info("Fetching all previous jobs");
        return repository.findAll();
    }

    public Optional<PreviousJob> getOne(Long id) {
        LOG.info("Trying to fetch a previous job with the following ID: {}", id);
        return repository.findById(id);
    }

    public List<PreviousJob> getPreviousJobsForCandidate(Long candidateId) {
        LOG.info("Fetching all previous jobs for a candidate with the following ID: {}", candidateId);
        return repository.findPreviousJobsByCandidateId(candidateId);
    }

    public PreviousJob update(PreviousJob previousJob, Long id) {
        LOG.info("Updating a previous job with the following ID: {}", id);
        return repository.findById(id)
                .map(pj -> {
                    var foundPj = pj.toBuilder()
                            .candidateId(previousJob.getCandidateId())
                            .title(previousJob.getTitle())
                            .level(previousJob.getLevel())
                            .description(previousJob.getDescription())
                            .updatedAt(LocalDateTime.now())
                            .build();
                    return repository.save(foundPj);
                }).orElseThrow();
    }

    public void delete(PreviousJob previousJob) {
        LOG.info("Deleting a previous job");
        repository.delete(previousJob);
    }

    public void delete(Long id) {
        LOG.info("Deleting a previous job with the following ID: {}", id);
        repository.deleteById(id);
    }
}

