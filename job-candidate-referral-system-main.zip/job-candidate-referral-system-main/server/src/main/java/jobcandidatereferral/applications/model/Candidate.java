package jobcandidatereferral.applications.model;
import jobcandidatereferral.applications.model.Candidate;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.Hidden;
import jakarta.persistence.*;
import lombok.*;
import org.hibernate.Hibernate;
import org.springframework.hateoas.RepresentationModel;

import java.time.LocalDateTime;
import java.util.Objects;

@Getter
@Setter
@ToString
@RequiredArgsConstructor
@AllArgsConstructor(staticName = "of")
@NoArgsConstructor(force = true)
@Builder(toBuilder = true)
@Entity
@Table(name = "candidate")
public class Candidate extends RepresentationModel<Candidate> {
    @Hidden
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "first_name")
    @NonNull
    private String firstName;

    @Column(name = "last_name")
    @NonNull
    private String lastName;

    @Column(name = "email")
    @NonNull
    private String email;

    @Column(name = "referrer_id")
    @NonNull
    private Long referrerId;

    @Column(name = "credential_id")
    private Long credentialId; // Education

    @Column(name = "previous_job_id")
    private Long previousJobId; // Work experience

    @Column(name = "referee_id")
    private Long refereeId; // Reference person (candidate provided) to talk bout the candidate

    @Column(name = "military_affiliated")
    private boolean militaryAffiliated;

    @JsonIgnore
    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @JsonIgnore
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null || Hibernate.getClass(this) != Hibernate.getClass(other)) {
            return false;
        }

        Candidate candidate = (Candidate) other;
        return this.id != null && Objects.equals(this.id, candidate.getId());
    }

    @Override
    public int hashCode() {
        return getClass().hashCode();
    }
}

