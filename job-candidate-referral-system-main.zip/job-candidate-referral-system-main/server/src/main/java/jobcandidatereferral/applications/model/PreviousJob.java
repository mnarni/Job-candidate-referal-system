package jobcandidatereferral.applications.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.Hidden;
import jakarta.persistence.*;
import lombok.*;
import org.hibernate.Hibernate;
import org.springframework.hateoas.RepresentationModel;

import java.time.LocalDateTime;
import java.util.Objects;

@Getter
@Setter
@ToString
@RequiredArgsConstructor
@AllArgsConstructor(staticName = "of")
@NoArgsConstructor(force = true)
@Builder(toBuilder = true)
@Entity
@Table(name = "previous_job")
public class PreviousJob extends RepresentationModel<PreviousJob> {
    @Hidden
    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "candidate_id")
    @NonNull
    private Long candidateId;

    @Column(name = "title")
    @NonNull
    private String title;

    @Column(name = "level")
    @NonNull
    private String level;

    @Column(name = "description")
    private String description;

    @JsonIgnore
    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @JsonIgnore
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }

        if (other == null || Hibernate.getClass(this) != Hibernate.getClass(other)) {
            return false;
        }

        PreviousJob otherJob = (PreviousJob) other;
        return this.id != null && Objects.equals(this.id, otherJob.getId());
    }

    @Override
    public int hashCode() {
        return getClass().hashCode();
    }
}

