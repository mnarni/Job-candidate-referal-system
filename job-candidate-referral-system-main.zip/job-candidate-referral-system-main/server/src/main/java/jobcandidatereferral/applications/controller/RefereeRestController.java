package jobcandidatereferral.applications.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jobcandidatereferral.applications.model.JobApplication;
import jobcandidatereferral.applications.model.Referee;
import jobcandidatereferral.applications.service.RefereeService;
import lombok.RequiredArgsConstructor;
import org.springframework.hateoas.EntityModel;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import static jobcandidatereferral.JCRSBase.HAL_JSON;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;


@RestController
@CrossOrigin
@RequestMapping("/api/referees")
@Tag(name = "Referee", description = "Who the candidate has on their resume in the references section")
@RequiredArgsConstructor
public class RefereeRestController {
    private final RefereeService service;

    @Operation(summary = "Add a referee")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Referee added",
                    content = {@Content(mediaType = HAL_JSON,
                            schema = @Schema(implementation = JobApplication.class))}),
            @ApiResponse(responseCode = "400", description = "Bad request", content = @Content)
    })
    @PostMapping(produces = {HAL_JSON})
    public Referee create(@RequestBody Referee referee) {
        return service.create(referee);
    }

    @Operation(summary = "Get all referees")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Found referees",
                    content = {@Content(mediaType = HAL_JSON,
                            schema = @Schema(implementation = JobApplication.class))}),
            @ApiResponse(responseCode = "400", description = "Bad request", content = @Content),
            @ApiResponse(responseCode = "404", description = "Referees not found", content = @Content)
    })
    @GetMapping(produces = {HAL_JSON})
    public List<Referee> getAll() {
        return service.getAll().stream()
                .peek(referee -> referee.add(linkTo(this.getClass())
                        .slash(referee.getId())
                        .withSelfRel()))
                .collect(Collectors.toList());
    }

    @Operation(summary = "Get a referee")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Found a referee",
                    content = {@Content(mediaType = HAL_JSON,
                            schema = @Schema(implementation = JobApplication.class))}),
            @ApiResponse(responseCode = "400", description = "Bad request", content = @Content),
            @ApiResponse(responseCode = "404", description = "Referee not found", content = @Content)
    })
    @GetMapping(value = "/{id}", produces = {HAL_JSON})
    public EntityModel<Referee> getOne(@PathVariable Long id) {
        Referee referee = service.getOne(id).orElseThrow();
        EntityModel<Referee> ref = EntityModel.of(referee);

        // Self-links
        ref.add(linkTo(this.getClass())
                .slash(Objects.requireNonNull(ref.getContent()).getId())
                .withSelfRel());

        // Link back to all referees
        ref.add(linkTo(methodOn(this.getClass()).getAll())
                .withRel("allReferees"));

        return ref;
    }

    @Operation(summary = "Get all referees for a candidate")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Found referees",
                    content = {@Content(mediaType = HAL_JSON,
                            schema = @Schema(implementation = JobApplication.class))}),
            @ApiResponse(responseCode = "400", description = "Bad request", content = @Content),
            @ApiResponse(responseCode = "404", description = "Referees not found", content = @Content)
    })
    @GetMapping(value = "/{candidateId}/referees", produces = {HAL_JSON})
    public List<Referee> getRefereesForCandidate(@PathVariable Long candidateId) {
        return service.getRefereesForCandidate(candidateId);
    }

    @Operation(summary = "Update a referee")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Referee updated",
                    content = {@Content(mediaType = HAL_JSON,
                            schema = @Schema(implementation = JobApplication.class))}),
            @ApiResponse(responseCode = "400", description = "Bad request", content = @Content),
            @ApiResponse(responseCode = "404", description = "Referee not found", content = @Content)
    })
    @PutMapping(value = "/{id}", produces = {HAL_JSON})
    public Referee update(@RequestBody Referee referee, @PathVariable Long id) {
        return service.update(referee, id);
    }

    @Operation(summary = "Delete a referee")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Deleted a referee",
                    content = {@Content(mediaType = HAL_JSON,
                            schema = @Schema(implementation = JobApplication.class))}),
            @ApiResponse(responseCode = "400", description = "Bad request", content = @Content),
            @ApiResponse(responseCode = "404", description = "Referee not found", content = @Content)
    })
    @DeleteMapping(value = "/{id}", produces = {HAL_JSON})
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}

