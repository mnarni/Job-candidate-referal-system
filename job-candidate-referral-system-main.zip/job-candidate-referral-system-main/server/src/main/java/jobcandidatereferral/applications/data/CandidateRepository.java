package jobcandidatereferral.applications.data;

import jobcandidatereferral.applications.model.Candidate;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CandidateRepository extends JpaRepository<Candidate, Long> {
}

