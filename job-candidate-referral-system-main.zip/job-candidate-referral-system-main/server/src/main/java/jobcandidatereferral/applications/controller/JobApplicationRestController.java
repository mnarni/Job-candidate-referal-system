package jobcandidatereferral.applications.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jobcandidatereferral.applications.model.JobApplication;
import jobcandidatereferral.applications.service.JobApplicationService;
import jobcandidatereferral.employees.controller.RecruiterRestController;
import jobcandidatereferral.jobs.controller.JobController;
import lombok.RequiredArgsConstructor;
import org.springframework.hateoas.EntityModel;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import static jobcandidatereferral.JCRSBase.HAL_JSON;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;


@RestController
@CrossOrigin
@RequestMapping("/api/applications")
@Tag(name = "Job application", description = "An application for an open position in the company")
@RequiredArgsConstructor
public class JobApplicationRestController {
    private final JobApplicationService service;

    @Operation(summary = "Add a job application")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Job application added",
                    content = {@Content(mediaType = HAL_JSON,
                            schema = @Schema(implementation = JobApplication.class))}),
            @ApiResponse(responseCode = "400", description = "Bad request", content = @Content)
    })
    @PostMapping(produces = {HAL_JSON})
    public JobApplication create(@RequestBody JobApplication application) {
        return service.create(application);
    }

    @Operation(summary = "Get all job applications")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Found job applications",
                    content = {@Content(mediaType = HAL_JSON,
                            schema = @Schema(implementation = JobApplication.class))}),
            @ApiResponse(responseCode = "400", description = "Bad request", content = @Content),
            @ApiResponse(responseCode = "404", description = "Job applications not found", content = @Content)
    })
    @GetMapping(produces = {HAL_JSON})
    public List<JobApplication> getAll() {
        return service.getAll().stream()
                .peek(app -> {
                    // add Self-links
                    app.add(linkTo(this.getClass())
                            .slash(app.getId())
                            .withSelfRel());

                    // Link Job
                    app.add(linkTo(methodOn(JobController.class)
                            .getJob(app.getJobId()))
                            .withRel("job"));

                    // Link Candidate
                    app.add(linkTo(methodOn(CandidateRestController.class)
                            .getOne(app.getCandidateId()))
                            .withRel("candidate"));

                    // Link Recruiter
                    app.add(linkTo(methodOn(RecruiterRestController.class)
                            .getRecruiter(app.getRecruiterId()))
                            .withRel("recruiter"));

                }).collect(Collectors.toList());
    }

    @Operation(summary = "Get a job application")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Found a job application",
                    content = {@Content(mediaType = HAL_JSON,
                            schema = @Schema(implementation = JobApplication.class))}),
            @ApiResponse(responseCode = "400", description = "Bad request", content = @Content),
            @ApiResponse(responseCode = "404", description = "Job application not found", content = @Content)
    })
    @GetMapping(value = "/{id}", produces = {HAL_JSON})
    public EntityModel<JobApplication> getOne(@PathVariable Long id) {
        JobApplication jobApp = service.getOne(id).orElseThrow();
        EntityModel<JobApplication> app = EntityModel.of(jobApp);

        // Self-links
        app.add(linkTo(this.getClass())
                .slash(Objects.requireNonNull(app.getContent()).getId())
                .withSelfRel());

        // Link back to all applications
        app.add(linkTo(methodOn(this.getClass()).getAll())
                .withRel("allApplications"));

        // Link Job
        app.add(linkTo(methodOn(JobController.class)
                .getJob(Objects.requireNonNull(app.getContent()).getJobId()))
                .withRel("job"));

        // Link Candidate
        app.add(linkTo(methodOn(CandidateRestController.class)
                .getOne(app.getContent().getCandidateId()))
                .withRel("candidate"));

        // Link Recruiter
        app.add(linkTo(methodOn(RecruiterRestController.class)
                .getRecruiter(app.getContent().getRecruiterId()))
                .withRel("recruiter"));

        return app;
    }

    @Operation(summary = "Update a job application")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Job application updated",
                    content = {@Content(mediaType = HAL_JSON,
                            schema = @Schema(implementation = JobApplication.class))}),
            @ApiResponse(responseCode = "400", description = "Bad request", content = @Content),
            @ApiResponse(responseCode = "404", description = "Job application not found", content = @Content)
    })
    @PutMapping(value = "/{id}", produces = {HAL_JSON})
    public JobApplication update(@RequestBody JobApplication application, @PathVariable Long id) {
        return service.update(application, id);
    }

    @Operation(summary = "Delete a job application")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Deleted a job application",
                    content = {@Content(mediaType = HAL_JSON,
                            schema = @Schema(implementation = JobApplication.class))}),
            @ApiResponse(responseCode = "400", description = "Bad request", content = @Content),
            @ApiResponse(responseCode = "404", description = "Job application not found", content = @Content)
    })
    @DeleteMapping(value = "/{id}", produces = {HAL_JSON})
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}

