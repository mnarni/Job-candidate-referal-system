package jobcandidatereferral.applications.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jobcandidatereferral.applications.model.JobApplication;
import jobcandidatereferral.applications.model.PreviousJob;
import jobcandidatereferral.applications.service.PreviousJobService;
import lombok.RequiredArgsConstructor;
import org.springframework.hateoas.EntityModel;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import static jobcandidatereferral.JCRSBase.HAL_JSON;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;


@RestController
@CrossOrigin
@RequestMapping("/api/previousjobs")
@Tag(name = "Previous job", description = "A job previously held by the candidate somewhere else")
@RequiredArgsConstructor
public class PreviousJobRestController {
    private final PreviousJobService service;

    @Operation(summary = "Add a previous job")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Previous job added",
                    content = {@Content(mediaType = HAL_JSON,
                            schema = @Schema(implementation = JobApplication.class))}),
            @ApiResponse(responseCode = "400", description = "Bad request", content = @Content)
    })
    @PostMapping(produces = {HAL_JSON})
    public PreviousJob create(@RequestBody PreviousJob previousJob) {
        return service.create(previousJob);
    }

    @Operation(summary = "Get all previous jobs")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Found previous jobs",
                    content = {@Content(mediaType = HAL_JSON,
                            schema = @Schema(implementation = JobApplication.class))}),
            @ApiResponse(responseCode = "400", description = "Bad request", content = @Content),
            @ApiResponse(responseCode = "404", description = "Previous jobs not found", content = @Content)
    })
    @GetMapping(produces = {HAL_JSON})
    public List<PreviousJob> getAll() {
        return service.getAll().stream()
                .peek(job -> job.add(linkTo(this.getClass())
                        .slash(job.getId())
                        .withSelfRel()))
                .collect(Collectors.toList());
    }

    @Operation(summary = "Get a previous job")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Found a previous job",
                    content = {@Content(mediaType = HAL_JSON,
                            schema = @Schema(implementation = JobApplication.class))}),
            @ApiResponse(responseCode = "400", description = "Bad request", content = @Content),
            @ApiResponse(responseCode = "404", description = "Previous job not found", content = @Content)
    })
    @GetMapping(value = "/{id}", produces = {HAL_JSON})
    public EntityModel<PreviousJob> getOne(@PathVariable Long id) {
        PreviousJob job = service.getOne(id).orElseThrow();
        EntityModel<PreviousJob> prevJob = EntityModel.of(job);

        // Self-links
        prevJob.add(linkTo(this.getClass())
                .slash(Objects.requireNonNull(prevJob.getContent()).getId())
                .withSelfRel());

        // Link back to all previous jobs
        prevJob.add(linkTo(methodOn(this.getClass()).getAll())
                .withRel("allPreviousJobs"));

        return prevJob;
    }

    @Operation(summary = "Get all previous jobs for a candidate")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Found previous jobs",
                    content = {@Content(mediaType = HAL_JSON,
                            schema = @Schema(implementation = JobApplication.class))}),
            @ApiResponse(responseCode = "400", description = "Bad request", content = @Content),
            @ApiResponse(responseCode = "404", description = "Previous jobs not found", content = @Content)
    })
    @GetMapping(value = "/{candidateId}/previousjobs", produces = {HAL_JSON})
    public List<PreviousJob> getPreviousJobsForCandidate(@PathVariable Long candidateId) {
        return service.getPreviousJobsForCandidate(candidateId);
    }

    @Operation(summary = "Update a previous job")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Previous job updated",
                    content = {@Content(mediaType = HAL_JSON,
                            schema = @Schema(implementation = JobApplication.class))}),
            @ApiResponse(responseCode = "400", description = "Bad request", content = @Content),
            @ApiResponse(responseCode = "404", description = "Previous job not found", content = @Content)
    })
    @PutMapping(value = "/{id}", produces = {HAL_JSON})
    public PreviousJob update(@RequestBody PreviousJob previousJob, @PathVariable Long id) {
        return service.update(previousJob, id);
    }

    @Operation(summary = "Delete a previous job")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Deleted a previous job",
                    content = {@Content(mediaType = HAL_JSON,
                            schema = @Schema(implementation = JobApplication.class))}),
            @ApiResponse(responseCode = "400", description = "Bad request", content = @Content),
            @ApiResponse(responseCode = "404", description = "Previous job not found", content = @Content)
    })
    @DeleteMapping(value = "/{id}", produces = {HAL_JSON})
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}

