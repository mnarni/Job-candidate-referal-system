package jobcandidatereferral.applications.service;

import jobcandidatereferral.applications.data.CredentialRepository;
import jobcandidatereferral.applications.model.Credential;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Slf4j
@Service
@RequiredArgsConstructor
public class CredentialService {
    private final CredentialRepository repository;

    public Credential create(Credential credential) {
        LOG.info("Saving a credential to the DB");
        return repository.save(credential);
    }

    public List<Credential> getAll() {
        LOG.info("Fetching all credentials");
        return repository.findAll();
    }

    public Optional<Credential> getOne(Long id) {
        LOG.info("Trying to fetch a credential with the following ID: {}", id);
        return repository.findById(id);
    }

    public List<Credential> getCredentialsForCandidate(Long candidateId) {
        LOG.info("Fetching all credentials for a candidate with the following ID: {}", candidateId);
        return repository.findCredentialsByCandidateId(candidateId);
    }

    public Credential update(Credential credential, Long id) {
        LOG.info("Updating a credential with the following ID: {}", id);
        return repository.findById(id)
                .map(c -> {
                    var foundCred = c.toBuilder()
                            .candidateId(credential.getCandidateId())
                            .schoolId(credential.getSchoolId())
                            .yearsCompleted(credential.getYearsCompleted())
                            .graduated(credential.isGraduated())
                            .major(credential.getMajor())
                            .type(credential.getType())
                            .updatedAt(LocalDateTime.now())
                            .build();
                    return repository.save(foundCred);
                }).orElseThrow();
    }

    public void delete(Credential credential) {
        LOG.info("Deleting a credential");
        repository.delete(credential);
    }

    public void delete(Long id) {
        LOG.info("Deleting a credential with the following ID: {}", id);
        repository.deleteById(id);
    }
}

