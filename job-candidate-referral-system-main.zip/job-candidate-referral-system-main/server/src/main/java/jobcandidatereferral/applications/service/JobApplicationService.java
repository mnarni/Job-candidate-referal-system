package jobcandidatereferral.applications.service;

import jobcandidatereferral.applications.data.JobApplicationRepository;
import jobcandidatereferral.applications.model.JobApplication;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Slf4j
@Service
@RequiredArgsConstructor
public class JobApplicationService {
    private final JobApplicationRepository repository;

    public JobApplication create(JobApplication application) {
        LOG.info("Saving a job application to the DB");
        return repository.save(application);
    }

    public List<JobApplication> getAll() {
        LOG.info("Fetching all job applications");
        return repository.findAll();
    }

    public Optional<JobApplication> getOne(Long id) {
        LOG.info("Trying to fetch a job application with the following ID: {}", id);
        return repository.findById(id);
    }

    public JobApplication update(JobApplication application, Long id) {
        LOG.info("Updating a job application with the following ID: {}", id);
        return repository.findById(id)
                .map(app -> {
                    var foundApp = app.toBuilder()
                            .jobId(application.getJobId())
                            .candidateId(application.getCandidateId())
                            .recruiterId(application.getRecruiterId())
                            .updatedAt(LocalDateTime.now())
                            .build();
                    return repository.save(foundApp);
                }).orElseThrow();
    }

    public void delete(JobApplication application) {
        LOG.info("Deleting a job application");
        repository.delete(application);
    }

    public void delete(Long id) {
        LOG.info("Deleting a job application with the following ID: {}", id);
        repository.deleteById(id);
    }
}

