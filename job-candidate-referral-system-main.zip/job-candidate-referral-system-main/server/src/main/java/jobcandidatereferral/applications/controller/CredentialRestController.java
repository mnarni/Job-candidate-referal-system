package jobcandidatereferral.applications.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jobcandidatereferral.applications.model.Credential;
import jobcandidatereferral.applications.model.JobApplication;
import jobcandidatereferral.applications.service.CredentialService;
import lombok.RequiredArgsConstructor;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.server.mvc.WebMvcLinkBuilder;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import static jobcandidatereferral.JCRSBase.HAL_JSON;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;


@RestController
@CrossOrigin
@RequestMapping("/api/credentials")
@Tag(name = "Credential", description = "An educational attainment, e.g. certificate, degree")
@RequiredArgsConstructor
public class CredentialRestController {
    private final CredentialService service;

    @Operation(summary = "Add a credential")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Credential added",
                    content = {@Content(mediaType = HAL_JSON,
                            schema = @Schema(implementation = JobApplication.class))}),
            @ApiResponse(responseCode = "400", description = "Bad request", content = @Content)
    })
    @PostMapping(produces = {HAL_JSON})
    public Credential create(@RequestBody Credential credential) {
        return service.create(credential);
    }

    @Operation(summary = "Get all credentials")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Found credentials",
                    content = {@Content(mediaType = HAL_JSON,
                            schema = @Schema(implementation = JobApplication.class))}),
            @ApiResponse(responseCode = "400", description = "Bad request", content = @Content),
            @ApiResponse(responseCode = "404", description = "Credentials not found", content = @Content)
    })
    @GetMapping(produces = {HAL_JSON})
    public List<Credential> getAll() {
        return service.getAll().stream()
                .peek(credential -> credential.add(linkTo(this.getClass())
                        .slash(credential.getId())
                        .withSelfRel()))
                .collect(Collectors.toList());
    }

    @Operation(summary = "Get a credential")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Found a credential",
                    content = {@Content(mediaType = HAL_JSON,
                            schema = @Schema(implementation = JobApplication.class))}),
            @ApiResponse(responseCode = "400", description = "Bad request", content = @Content),
            @ApiResponse(responseCode = "404", description = "Credential not found", content = @Content)
    })
    @GetMapping(value = "/{id}", produces = {HAL_JSON})
    public EntityModel<Credential> getOne(@PathVariable Long id) {
        Credential credential = service.getOne(id).orElseThrow();
        EntityModel<Credential> cred = EntityModel.of(credential);

        // Self-links
        cred.add(linkTo(this.getClass())
                .slash(Objects.requireNonNull(cred.getContent()).getId()).withSelfRel());

        // Link back to all credentials
        WebMvcLinkBuilder link = linkTo(methodOn(this.getClass()).getAll());
        cred.add(link.withRel("allCredentials"));

        return cred;
    }

    @Operation(summary = "Get all credentials for a candidate")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Found credentials",
                    content = {@Content(mediaType = HAL_JSON,
                            schema = @Schema(implementation = JobApplication.class))}),
            @ApiResponse(responseCode = "400", description = "Bad request", content = @Content),
            @ApiResponse(responseCode = "404", description = "Credentials not found", content = @Content)
    })
    @GetMapping(value = "/{candidateId}/credentials", produces = {HAL_JSON})
    public List<Credential> getCredentialsForCandidate(@PathVariable Long candidateId) {
        return service.getCredentialsForCandidate(candidateId);
    }

    @Operation(summary = "Update a credential")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Credential updated",
                    content = {@Content(mediaType = HAL_JSON,
                            schema = @Schema(implementation = JobApplication.class))}),
            @ApiResponse(responseCode = "400", description = "Bad request", content = @Content),
            @ApiResponse(responseCode = "404", description = "Credential not found", content = @Content)
    })
    @PutMapping(value = "/{id}", produces = {HAL_JSON})
    public Credential update(@RequestBody Credential credential, @PathVariable Long id) {
        return service.update(credential, id);
    }

    @Operation(summary = "Delete a credential")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Deleted a credential",
                    content = {@Content(mediaType = HAL_JSON,
                            schema = @Schema(implementation = JobApplication.class))}),
            @ApiResponse(responseCode = "400", description = "Bad request", content = @Content),
            @ApiResponse(responseCode = "404", description = "Credential not found", content = @Content)
    })
    @DeleteMapping(value = "/{id}", produces = {HAL_JSON})
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}

