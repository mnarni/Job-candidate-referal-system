package jobcandidatereferral.applications.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.Hidden;
import jakarta.persistence.*;
import lombok.*;
import org.hibernate.Hibernate;
import org.springframework.hateoas.RepresentationModel;

import java.time.LocalDateTime;
import java.util.Objects;

import static com.fasterxml.jackson.annotation.JsonProperty.Access.WRITE_ONLY;

@Getter
@Setter
@ToString
@RequiredArgsConstructor
@AllArgsConstructor(staticName = "of")
@NoArgsConstructor(force = true)
@Builder(toBuilder = true)
@Entity
@Table(name = "job_application")
public class JobApplication extends RepresentationModel<JobApplication> {
    @Hidden
    @JsonProperty(access = WRITE_ONLY)
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @JsonProperty(access = WRITE_ONLY)
    @Column(name = "job_id")
    @NonNull
    private Long jobId;

    @JsonProperty(access = WRITE_ONLY)
    @Column(name = "candidate_id")
    @NonNull
    private Long candidateId;

    @JsonProperty(access = WRITE_ONLY)
    @Column(name = "recruiter_id")
    @NonNull
    private Long recruiterId;

    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @JsonProperty(access = WRITE_ONLY)
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }

        if (other == null || Hibernate.getClass(this) != Hibernate.getClass(other)) {
            return false;
        }

        JobApplication otherJobApp = (JobApplication) other;

        return this.id != null && Objects.equals(this.id, otherJobApp.getId());
    }

    @Override
    public int hashCode() {
        return getClass().hashCode();
    }
}

