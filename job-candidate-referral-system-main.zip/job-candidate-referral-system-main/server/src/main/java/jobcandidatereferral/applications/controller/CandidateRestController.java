package jobcandidatereferral.applications.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jobcandidatereferral.applications.model.Candidate;
import jobcandidatereferral.applications.model.JobApplication;
import jobcandidatereferral.applications.service.CandidateService;
import jobcandidatereferral.applications.service.CredentialService;
import jobcandidatereferral.applications.service.PreviousJobService;
import jobcandidatereferral.applications.service.RefereeService;
import jobcandidatereferral.employees.controller.EmployeeRestController;
import lombok.RequiredArgsConstructor;
import org.springframework.hateoas.EntityModel;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import static jobcandidatereferral.JCRSBase.HAL_JSON;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.reactive.WebFluxLinkBuilder.methodOn;


@RestController
@CrossOrigin
@RequestMapping("/api/candidates")
@Tag(name = "Candidate", description = "Someone who has been referred for an open position")
@RequiredArgsConstructor
public class CandidateRestController {
    private final CandidateService candidateService;
    private final CredentialService credentialService;
    private final PreviousJobService previousJobService;
    private final RefereeService refereeService;

    @Operation(summary = "Add a candidate")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Candidate added",
                    content = {@Content(mediaType = HAL_JSON,
                            schema = @Schema(implementation = JobApplication.class))}),
            @ApiResponse(responseCode = "400", description = "Bad request", content = @Content)
    })
    @PostMapping(produces = {HAL_JSON})
    public Candidate create(@RequestBody Candidate candidate) {
        return candidateService.create(candidate);
    }

    @Operation(summary = "Get all candidates")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Found candidates",
                    content = {@Content(mediaType = HAL_JSON,
                            schema = @Schema(implementation = JobApplication.class))}),
            @ApiResponse(responseCode = "400", description = "Bad request", content = @Content),
            @ApiResponse(responseCode = "404", description = "Candidates not found", content = @Content)
    })
    @GetMapping(produces = {HAL_JSON})
    public List<Candidate> getAll() {
        return candidateService.getAll().stream()
                .peek(candidate -> candidate.add(linkTo(this.getClass())
                        .slash(candidate.getId())
                        .withSelfRel()))
                .collect(Collectors.toList());
    }

    @Operation(summary = "Get a candidate")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Found a candidate",
                    content = {@Content(mediaType = HAL_JSON,
                            schema = @Schema(implementation = JobApplication.class))}),
            @ApiResponse(responseCode = "400", description = "Bad request", content = @Content),
            @ApiResponse(responseCode = "404", description = "Candidate not found", content = @Content)
    })
    @GetMapping(value = "/{id}", produces = {HAL_JSON})
    public EntityModel<Candidate> getOne(@PathVariable Long id) {
        Candidate candidate = candidateService.getOne(id).orElseThrow();
        EntityModel<Candidate> candi = EntityModel.of(candidate);

        // Self-links
        candi.add(linkTo(this.getClass())
                .slash(Objects.requireNonNull(candi.getContent()).getId())
                .withSelfRel());

        // Link back to all candidates
        candi.add(linkTo(methodOn(this.getClass()).getAll())
                .withRel("allCandidates"));

        // Link Referrer
        candi.add(linkTo(methodOn(EmployeeRestController.class)
                .getEmployee(candidate.getReferrerId()))
                .withRel("referrer"));

        // Link Credentials
        candi.add(linkTo(methodOn(CredentialRestController.class)
                .getCredentialsForCandidate(candidate.getId()))
                .withRel("credentials"));

        // TODO: Deep-link credentials?
        var links = credentialService.getCredentialsForCandidate(id).stream().peek(credential -> {
            // add Self-links
            credential.add(linkTo(this.getClass())
                    .slash(credential.getCandidateId())
                    .withSelfRel());

        }).toList();

        // Link Previous Jobs
        candi.add(linkTo(methodOn(PreviousJobRestController.class)
                .getPreviousJobsForCandidate(candidate.getId()))
                .withRel("previousJobs"));

        // TODO: Deep-link previous jobs?
        var links2 = previousJobService.getPreviousJobsForCandidate(id).stream()
                .peek(previousJob -> {
                    // add Self-links
                    previousJob.add(linkTo(PreviousJobRestController.class)
                            .slash(previousJob.getCandidateId())
                            .withSelfRel());
                }).toList();

        // Link Referees
        candi.add(linkTo(methodOn(RefereeRestController.class)
                .getRefereesForCandidate(candidate.getId()))
                .withRel("referees"));

        // TODO: Deep-link referees?
        var links3 = refereeService.getRefereesForCandidate(id).stream()
                .peek(referee -> {
                    // add Self-links
                    referee.add(linkTo(RefereeRestController.class)
                            .slash(referee.getCandidateId())
                            .withSelfRel());
                }).toList();

        return candi;
    }

    @Operation(summary = "Update a candidate")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Candidate updated",
                    content = {@Content(mediaType = HAL_JSON,
                            schema = @Schema(implementation = JobApplication.class))}),
            @ApiResponse(responseCode = "400", description = "Bad request", content = @Content),
            @ApiResponse(responseCode = "404", description = "Candidate not found", content = @Content)
    })
    @PutMapping(value = "/{id}", produces = {HAL_JSON})
    public Candidate update(@RequestBody Candidate candidate, @PathVariable Long id) {
        return candidateService.update(candidate, id);
    }

    @Operation(summary = "Delete a candidate")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Deleted a candidate",
                    content = {@Content(mediaType = HAL_JSON,
                            schema = @Schema(implementation = JobApplication.class))}),
            @ApiResponse(responseCode = "400", description = "Bad request", content = @Content),
            @ApiResponse(responseCode = "404", description = "Candidate not found", content = @Content)
    })
    @DeleteMapping(value = "/{id}", produces = {HAL_JSON})
    public void delete(@PathVariable Long id) {
        candidateService.delete(id);
    }
}

