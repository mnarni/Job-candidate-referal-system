package jobcandidatereferral.applications.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.Hidden;
import jakarta.persistence.*;
import lombok.*;
import org.hibernate.Hibernate;
import org.springframework.hateoas.RepresentationModel;

import java.time.LocalDateTime;
import java.util.Objects;

@Getter
@Setter
@ToString
@RequiredArgsConstructor
@AllArgsConstructor(staticName = "of")
@NoArgsConstructor(force = true)
@Builder(toBuilder = true)
@Entity
@Table(name = "credential")
public class Credential extends RepresentationModel<Credential> {
    @Hidden
    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "candidate_id")
    @NonNull
    private Long candidateId;

    @Column(name = "school_id")
    @NonNull
    private Integer schoolId;

    @Column(name = "years_completed")
    @NonNull
    private Integer yearsCompleted;

    @Column(name = "graduated")
    private boolean graduated;

    @Column(name = "major")
    private String major;

    @Column(name = "credential_type")
    @NonNull
    private String type;

    @JsonIgnore
    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @JsonIgnore
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }

        if (other == null || Hibernate.getClass(this) != Hibernate.getClass(other)) {
            return false;
        }

        Credential otherCredential = (Credential) other;
        return this.id != null && Objects.equals(this.id, otherCredential.getId());
    }

    @Override
    public int hashCode() {
        return getClass().hashCode();
    }
}

