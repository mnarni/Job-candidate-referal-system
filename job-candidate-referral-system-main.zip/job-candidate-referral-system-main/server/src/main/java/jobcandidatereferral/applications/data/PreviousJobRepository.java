package jobcandidatereferral.applications.data;

import jobcandidatereferral.applications.model.PreviousJob;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface PreviousJobRepository extends JpaRepository<PreviousJob, Long> {
    List<PreviousJob> findPreviousJobsByCandidateId(long candidateId);
}

