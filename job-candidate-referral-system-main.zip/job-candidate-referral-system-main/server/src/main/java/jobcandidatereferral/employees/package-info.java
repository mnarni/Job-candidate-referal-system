
/**
 * <h1 style="text-decoration: underline;">Documentation for the 'Employees'
 * portion of this system</h1>
 * 
 * <p>
 * This feature allows to add, update, delete and get the employee details in
 * the job referral system
 * </p>
 * <p>
 * Developer: Mounica Narni
 * </p>
 * <ol>
 * <li>DB wiring and/or seeding
 * <ul>
 * <li>Schema: See <strong>server/src/main/resources/schema.sql (feature ->
 * Employees)</strong></li>
 * <li>Seeding: See <strong>server/src/main/resources/data.sql</strong></li>
 * </ul>
 * </li>
 * <li>REST Endpoint: <a href=
 * "http://localhost:8008/api/employees">http://localhost:8008/api/employees</a></li>
 * <li>API docs: <a href=
 * "http://localhost:8008/swagger-ui/index.html#/Employee_service">http://localhost:8008/swagger-ui/index.html#/Employee_services</a></li>
 * <li>Unit Tests: [in progress] JUnit 5 will be used</li>
 * </ol>
 *
 * <hr>
 *
 * <h2>Work items</h2>
 * <h4><strong>Base directory:</strong> job-candidate-referral-system</h4>
 * <h4><strong>Scripts directory:</strong> /scripts</h4>
 * <h3><span style="text-decoration: underline;">Backend</span></h3>
 * <h4><strong>Feature package:</strong>
 * /server/src/main/java/jobcandidatereferral/employees</h4>
 * <ul>
 * <li>Put together bash scripts for operating the employees feature of the
 * application (scripts directory above).</li>
 * <li>Wrote all Employees and Recruiters feature CRUD.</li>
 * <li>
 * <p>
 * Fully documented REST API endpoints with OpenAPI 3.0
 * </p>
 * <p>
 * See the following on
 * <a href="http://localhost:8008/swagger-ui/index.html">Swagger UI</a>
 * </p>
 * <ul>
 * <li>Employee</li>
 * <li>Recruiter</li>
 * </ul>
 * </li>
 * </ul>
 * 
 * <p>
 * ======
 * </p>
 * <br>
 *
 * <h3><span style="text-decoration: underline;">Frontend</span></h3>
 * <h4><strong>Feature package:</strong> /client/src/employees</h4>
 * <ul>
 * <li>Configured nvm for the application</li>
 * <li>Added CSS to the login and side nav screens</li>
 * <li>Put together the LoginScreen and SideNav pages.</li>
 * <li>Login Authentication and Authorization functionality</li>
 * <li>Wrote all Employees feature CRUD.</li>
 * </ul>
 * 
 * @version 1.0
 * @author Mounica Narni
 * @since 0.0.1
 */
package jobcandidatereferral.employees;
