package jobcandidatereferral.employees.service;

import jobcandidatereferral.employees.data.RecruiterRepository;
import jobcandidatereferral.employees.model.Recruiter;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class RecruiterService {
    private final RecruiterRepository recruiterRepository;

    public List<Recruiter> getAll() {
        return recruiterRepository.findAll();
    }

    public Optional<Recruiter> getOne(long id) {
        return recruiterRepository.findById(id);
    }
}
