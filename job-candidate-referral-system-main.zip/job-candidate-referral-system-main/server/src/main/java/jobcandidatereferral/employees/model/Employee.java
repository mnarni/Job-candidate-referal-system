package jobcandidatereferral.employees.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

@Data
@Entity
public class Employee {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long eid;

    @NotBlank
    @Column(name = "first_name")
    private String firstName;

    @NotBlank
    @Column(name = "last_name")
    private String lastName;

    @NotBlank
    @Email
    private String email;

    @NotBlank
    private String title;

    @Column(name="created_at")
    @DateTimeFormat
    private String createdAt;

    @Column(name="updated_at")
    @DateTimeFormat
    private String updatedAt;
}
