package jobcandidatereferral.employees.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jobcandidatereferral.employees.model.Employee;
import jobcandidatereferral.employees.service.EmployeeService;
import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.server.mvc.WebMvcLinkBuilder;
import org.springframework.http.HttpStatus;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import static jobcandidatereferral.JCRSBase.HAL_JSON;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

@RestController
@CrossOrigin
@RequestMapping("/api/employees")
@Tag(name = "Employee", description = "Everything about employees")
@Log4j2
@RequiredArgsConstructor
public class EmployeeRestController {
    private final EmployeeService service;

    // @GetMapping("/all")
    // @Operation(summary = "Returns all the employees")
    // @ApiResponse(responseCode = "200", description = "valid response",
    //         content = {@Content(mediaType="application/json", schema=@Schema(implementation= Employee.class))})
    // public List<Employee> getAllUsers() {
    //     return employeeRepository.findAll();
    // }

    // @GetMapping("/{eid}")
    // @Operation(summary = "Returns the user with a specific eid")
    // @ApiResponse(responseCode = "200", description = "valid response",
    //         content = {@Content(mediaType="application/json", schema=@Schema(implementation= Employee.class))})
    // public Employee getUser(@PathVariable("eid") long eid) {
    //     return employeeRepository.findById(eid).get();
    // }

    // @PostMapping
    // @Operation(summary = "Save the employee details and returns the emp id")
    // public long save(Employee employee) {
    //     LOG.traceEntry("enter save", employee);
    //     employeeRepository.save(employee);
    //     LOG.traceExit("exit save", employee);
    //     return employee.getEid();
    // }
    @GetMapping(produces = {HAL_JSON})
    @Operation(summary = "Returns the user with a specific uid")
    @ApiResponse(responseCode = "200", description = "valid response",
            content = {@Content(mediaType = HAL_JSON, schema = @Schema(implementation = Employee.class))})
    public List<Employee> getAll() {
        return service.getAll();
    }

    @GetMapping(value = "/{id}", produces = {HAL_JSON})
    public EntityModel<Employee> getEmployee(@PathVariable Long id) {
        Employee employee = service.getOne(id).orElseThrow();
        EntityModel<Employee> emp = EntityModel.of(employee);

        // Self-links
        emp.add(linkTo(this.getClass())
                .slash(Objects.requireNonNull(emp.getContent()).getEid()).withSelfRel());

        // Link back to all employees
        WebMvcLinkBuilder link = linkTo(methodOn(this.getClass()).getAll());
        emp.add(link.withRel("allEmployees"));

        return emp;
    }

    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public Map<String, String> handleValidationExceptions(MethodArgumentNotValidException ex) {
        Map<String, String> errors = new HashMap<>();
        ex.getBindingResult().getAllErrors().forEach((error) -> {
            String fieldName = ((FieldError) error).getField();
            String errorMessage = error.getDefaultMessage();
            errors.put(fieldName, errorMessage);
        });
        return errors;
    }
}

