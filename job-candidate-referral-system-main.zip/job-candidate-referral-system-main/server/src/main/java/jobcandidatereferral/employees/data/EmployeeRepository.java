package jobcandidatereferral.employees.data;

import jobcandidatereferral.employees.model.Employee;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.FluentQuery;

import java.util.List;
import java.util.Optional;
import java.util.function.Function;


public interface EmployeeRepository extends JpaRepository<Employee, Long> {

    public void flush();


    <S extends Employee> S saveAndFlush(S entity);

    <S extends Employee> List<S> saveAllAndFlush(Iterable<S> entities);

    void deleteAllInBatch(Iterable<Employee> entities);

    void deleteAllByIdInBatch(Iterable<Long> longs);

    void deleteAllInBatch();

    Employee getOne(Long aLong);

    Employee getById(Long aLong);

    Employee getReferenceById(Long aLong);

    <S extends Employee> Optional<S> findOne(Example<S> example);

    <S extends Employee> List<S> findAll(Example<S> example);

    <S extends Employee> List<S> findAll(Example<S> example, Sort sort);

    <S extends Employee> Page<S> findAll(Example<S> example, Pageable pageable);

    <S extends Employee> long count(Example<S> example);
    <S extends Employee> boolean exists(Example<S> example);

    <S extends Employee, R> R findBy(Example<S> example, Function<FluentQuery.FetchableFluentQuery<S>, R> queryFunction);

    <S extends Employee> S save(S entity);

    <S extends Employee> List<S> saveAll(Iterable<S> entities);

    Optional<Employee> findById(Long aLong);

    boolean existsById(Long aLong);

    List<Employee> findAll();

    List<Employee> findAllById(Iterable<Long> longs);

    long count();

    void deleteById(Long aLong);

    void delete(Employee entity);

    void deleteAllById(Iterable<? extends Long> longs);

    void deleteAll(Iterable<? extends Employee> entities);

    void deleteAll();

    List<Employee> findAll(Sort sort);

    Page<Employee> findAll(Pageable pageable);

    Optional<Employee> findByEmail(String email);
}


