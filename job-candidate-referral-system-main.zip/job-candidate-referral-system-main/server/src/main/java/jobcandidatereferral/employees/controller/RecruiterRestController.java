package jobcandidatereferral.employees.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jobcandidatereferral.employees.model.Recruiter;
import jobcandidatereferral.employees.service.RecruiterService;
import lombok.RequiredArgsConstructor;
import org.springframework.hateoas.EntityModel;
import org.springframework.web.bind.annotation.*;

import java.util.List;

import static jobcandidatereferral.JCRSBase.HAL_JSON;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;

@RestController
@CrossOrigin
@RequestMapping("/api/recruiters")
@Tag(name = "Recruiter", description = "Recruiter for the company")
@RequiredArgsConstructor
public class RecruiterRestController {
    private final RecruiterService service;

    @Operation(summary = "Get all recruiters")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Found recruiters",
                    content = {@Content(mediaType = HAL_JSON,
                            schema = @Schema(implementation = Recruiter.class))}),
            @ApiResponse(responseCode = "400", description = "Bad request", content = @Content),
            @ApiResponse(responseCode = "404", description = "Recruiters not found", content = @Content)
    })
    @GetMapping
    public List<Recruiter> getAll() {
        return service.getAll();
    }

    @GetMapping("/{id}")
    public EntityModel<Recruiter> getRecruiter(@PathVariable Long id) {
        Recruiter recruiter = service.getOne(id).orElseThrow();
        EntityModel<Recruiter> recruiterModel = EntityModel.of(recruiter);

        recruiterModel.add(linkTo(this.getClass())
                .slash(recruiter.getRecruiterId()).withSelfRel());

        return recruiterModel;
    }
}
