package jobcandidatereferral.employees.service;


import jobcandidatereferral.employees.data.EmployeeRepository;
import jobcandidatereferral.employees.model.Employee;
import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Log4j2
@Service
@RequiredArgsConstructor
public class EmployeeService {
    private final EmployeeRepository repo;

    public List<Employee> getAll() {
        return repo.findAll();
    }

    public Optional<Employee> getOne(Long id) {
        return repo.findById(id);
    }

    public Employee getEmployeeByEmail(String email) {
        return repo.findByEmail(email).orElse(new Employee());
    }

    public long add(Employee employee) {
        var savedEmp = repo.save(employee);
        return savedEmp.getEid();
    }

    public void delete(Long id) {
        repo.deleteById(id);
    }

    public Employee update(Employee employee) {
        var repoEmployee = getOne(employee.getEid()).orElseThrow();

        repoEmployee.setFirstName(employee.getFirstName());
        repoEmployee.setLastName(employee.getLastName());
        repoEmployee.setEmail(employee.getEmail());
        repoEmployee.setTitle(employee.getTitle());
        repoEmployee.setEid(employee.getEid());
        repoEmployee.setCreatedAt(employee.getCreatedAt());
        repoEmployee.setUpdatedAt(employee.getUpdatedAt());

        return repo.save(repoEmployee);
    }
}

