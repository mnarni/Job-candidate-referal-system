package jobcandidatereferral.jobs.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jobcandidatereferral.applications.model.Candidate;
import jobcandidatereferral.applications.service.CandidateService;
import jobcandidatereferral.jobs.model.EmailData;
import jobcandidatereferral.jobs.service.EmailService;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

@RestController
@CrossOrigin
@RequestMapping("/api/emails")
@Tag(name = "Email", description = "Used to send an email")
@Log4j2
public class EmailController {
    @Autowired
    EmailService emailService;
    @Autowired
    CandidateService candidateService;

    @PostMapping(path = "/send",
            consumes = MediaType.APPLICATION_JSON_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    @Operation(summary = "Send the email")
    @ApiResponse(responseCode = "200", description = "valid response",
            content = {@Content(mediaType = "application/json", schema = @Schema(implementation = EmailData.class))})
    public long send(@RequestBody  EmailData emailData) {
        Candidate newCandidate = new Candidate();
        newCandidate.setEmail(emailData.getCandidateEmail());
        newCandidate.setFirstName(emailData.getCandidateFirstName());
        newCandidate.setLastName(emailData.getCandidateLastName());
        newCandidate.setReferrerId(emailData.getRecruiterId());

        newCandidate = candidateService.create(newCandidate);
        emailService.sendEmail(emailData);
        return newCandidate.getId();
    }
}
