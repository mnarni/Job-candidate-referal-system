package jobcandidatereferral.jobs.data;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Predicate;
import jakarta.persistence.criteria.Root;
import jobcandidatereferral.jobs.model.Job;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class JobFilteringRepositoryImpl implements JobFilteringRepository {
    @PersistenceContext
    private EntityManager entityManager;

    @Override
    public List<Job> findJobByFilters(Map<String, String> jobSearchParamsSet) {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<Job> query = cb.createQuery(Job.class);
        Root<Job> job = query.from(Job.class);

        List<Predicate> predicates = new ArrayList<>();
        for (Map.Entry<String, String> param: jobSearchParamsSet.entrySet()) {
            String[] vals = param.getValue().split(",");
            predicates.add(job.get(param.getKey()).in((Object) vals));
        }
        query.select(job)
                .where(cb.or(predicates.toArray(new Predicate[0])));

        return entityManager.createQuery(query)
                .getResultList();
    }
}
