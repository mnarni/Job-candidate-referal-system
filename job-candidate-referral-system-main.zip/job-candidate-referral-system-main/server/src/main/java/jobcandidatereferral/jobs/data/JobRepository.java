package jobcandidatereferral.jobs.data;

import jobcandidatereferral.jobs.model.Job;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface JobRepository extends JpaRepository<Job, Long>, JobFilteringRepository {

    @Query("FROM Job j WHERE j.recruiterId=?1")
    List<Job> findByRecruiter(long rid);

    @Query("FROM Job j WHERE j.filled='N'")
    List<Job> findOpenJobs();

    @Query("FROM Job j WHERE j.level=?1")
    List<Job> findByRecruiter(String level);
}
