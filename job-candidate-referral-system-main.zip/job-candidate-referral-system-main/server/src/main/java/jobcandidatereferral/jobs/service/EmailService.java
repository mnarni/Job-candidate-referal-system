package jobcandidatereferral.jobs.service;

import jobcandidatereferral.jobs.model.EmailData;
import jakarta.mail.internet.MimeMessage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

@Service
public class EmailService {

    @Value("${spring.mail.username}")
    private String fromEmail;

    @Autowired
    private JavaMailSender javaMailSender;

    public void sendEmail(EmailData data) {
        try {
            MimeMessage email = javaMailSender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(email);
            helper.setFrom(fromEmail);
            helper.setTo(data.getCandidateEmail());
            helper.setSubject("You are invited to join J.C.R.S");

            StringBuilder builder = new StringBuilder();
            builder.append(String.format("Dear %s %s,", data.getCandidateFirstName(), data.getCandidateLastName()));
            builder.append(System.lineSeparator()).append(System.lineSeparator());
            builder.append(String.format("%s is inviting you to join J.C.R.S. for a/n %s %s role. Please follow the " +
                    "link below to complete your application:", data.getRecruiterName(), data.getJobTitle(), data.getJobLevel()));
            builder.append(System.lineSeparator());
            builder.append(data.getApplicationLink()).append(System.lineSeparator());
            builder.append("Welcome to J.C.R.S!");
            helper.setText(builder.toString());

            javaMailSender.send(email);
        } catch (Exception e) {
            System.out.println("bruh");
        }
    }
}
