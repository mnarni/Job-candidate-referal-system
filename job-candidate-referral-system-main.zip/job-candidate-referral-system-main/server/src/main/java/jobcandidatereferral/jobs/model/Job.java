package jobcandidatereferral.jobs.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.Data;

import java.sql.Timestamp;

@Data
@Entity
public class Job {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "jid")
    private Long jid;

    @NotNull
    @Column(name = "recruiter_id")
    private Integer recruiterId;

    @NotBlank
    @Column(name = "title")
    private String title;

    @NotBlank
    @Column(name = "level")
    private String level;

    @NotBlank
    @Column(name = "description")
    private String description;

    @NotEmpty
    @Column(name = "requirements")
    private String requirements;

    @Column(name = "created_at")
    private Timestamp createdAt;

    @Column(name = "updated_at")
    private Timestamp updatedAt;

    @NotNull
    @Column(name = "openings")
    @Positive(message = "Job must have at least 1 opening")
    private Integer openings;

    @NotEmpty
    @Column(name = "filled")
    private String filled;
}
