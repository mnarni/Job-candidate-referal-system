
/**
 * <h1 style="text-decoration: underline;">Documentation for the 'Job' portion of this system</h1>
 * <p>This feature allows an employee to browse/create a job posting</p>
 * <ol>
 *  <li>DB wiring and/or seeding
 *      <ul>
 *          <li>Schema: See <strong>../resources/schema.sql (Job table)</strong></li>
 *          <li>Seeding: See <strong>../resources/data.sql</strong></li>
 *      </ul>
 *  </li>
 *  <li>REST Endpoint: <a href="http://localhost:8008/api/applications">http://localhost:8008/api/jobs</a></li>
 *  <li>API docs: [in progress] Swagger will be used</li>
 *  <li>Unit Tests: [in progress] JUnit 5 will be used</li>
 * </ol>
 *
 * @author Marcel
 */
package jobcandidatereferral.jobs;

