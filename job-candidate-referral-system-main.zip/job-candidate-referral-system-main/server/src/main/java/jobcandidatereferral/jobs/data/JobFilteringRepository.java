package jobcandidatereferral.jobs.data;

import jobcandidatereferral.jobs.model.Job;

import java.util.List;
import java.util.Map;

public interface JobFilteringRepository {
        List<Job> findJobByFilters(Map<String, String> jobSearchParamsSet);
}
