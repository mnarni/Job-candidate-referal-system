package jobcandidatereferral.jobs.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jobcandidatereferral.jobs.data.JobRepository;
import jobcandidatereferral.jobs.model.Job;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.sql.Timestamp;
import java.util.*;

@RestController
@CrossOrigin
@RequestMapping("/api/jobs")
@Tag(name = "Job", description = "Everything about your Job")
@Log4j2
public class JobController {

    @Autowired
    private JobRepository jobRepository;

    @GetMapping("/all")
    @Operation(summary = "Returns the job with a specific pid")
    @ApiResponse(responseCode = "200", description = "valid response",
            content = {@Content(mediaType = "application/json", schema = @Schema(implementation = Job.class))})
    public List<Job> getJob() {
        return jobRepository.findAll();
    }

    @GetMapping("/{jid}")
    @Operation(summary = "Returns the job with a specific pid")
    @ApiResponse(responseCode = "200", description = "valid response",
            content = {@Content(mediaType = "application/json", schema = @Schema(implementation = Job.class))})
    public Job getJob(@PathVariable("jid") long jid) {
        LOG.info("value is: " + jid);
        Optional<Job> job = jobRepository.findById(jid);
        return job.orElse(null);
    }

    @GetMapping("/recruiter/{rid}")
    @Operation(summary = "Returns all the positions by their recruiter")
    @ApiResponse(responseCode = "200", description = "valid response",
            content = {@Content(mediaType = "application/json", schema = @Schema(implementation = Job.class))})
    public List<Job> getJobsByRecruiter(@PathVariable("rid") long rid) {
        return jobRepository.findByRecruiter(rid);
    }

    @GetMapping("/open")
    @Operation(summary = "Returns all the open jobs")
    @ApiResponse(responseCode = "200", description = "valid response",
            content = {@Content(mediaType = "application/json", schema = @Schema(implementation = Job.class))})
    public List<Job> getOpenJobs() {
        return jobRepository.findOpenJobs();
    }

    @GetMapping("/level/{level}")
    @Operation(summary = "Returns all the positions by their recruiter")
    @ApiResponse(responseCode = "200", description = "valid response",
            content = {@Content(mediaType = "application/json", schema = @Schema(implementation = Job.class))})
    public List<Job> getJobsByLevel(@PathVariable("level") String level) {
        return jobRepository.findByRecruiter(level);
    }

    @PostMapping("/filter")
    @Operation(summary = "Save the job and returns the job id")
    public List<Job> filterJobs(@RequestParam Map<String, String> params) {
        return jobRepository.findJobByFilters(params);
    }

    @PostMapping
    @Operation(summary = "Save the job and returns the job id")
    public long save(Job job) {
        LOG.traceEntry("enter save", job);
        jobRepository.save(job);
        LOG.traceExit("exit save", job);
        return job.getJid();
    }

    @PutMapping
    @Operation(summary = "Updates the job")
    public Job update(@RequestBody Job jobUpdate) {
        LOG.traceEntry("enter save", jobUpdate);
        Job job = jobRepository.findById((long) jobUpdate.getJid()).orElse(null);
        if (job != null && Objects.equals(job.getRecruiterId(), jobUpdate.getRecruiterId())) {
            job.setDescription(jobUpdate.getDescription());
            job.setTitle(jobUpdate.getTitle());
            job.setLevel(jobUpdate.getLevel());
            job.setOpenings(jobUpdate.getOpenings());
            job.setRequirements(jobUpdate.getRequirements());
            job.setFilled(jobUpdate.getFilled());
            job.setUpdatedAt(new Timestamp(new Date().getTime()));
            LOG.traceExit("exit save", job);
            return jobRepository.save(job);
        } else {
            return null;
        }
    }
}
