package jobcandidatereferral.jobs.model;

import lombok.Data;

@Data
public class EmailData {

    private long jobId;

    private String recruiterName;
    private long recruiterId;

    private String candidateFirstName;
    private String candidateLastName;
    private String candidateEmail;

    private String jobTitle;
    private String jobLevel;

    private String applicationLink;
}
