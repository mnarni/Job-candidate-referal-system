import io.swagger.v3.oas.models.ExternalDocumentation;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.info.License;
import jobcandidatereferral.JCRSBase;
import org.springdoc.core.models.GroupedOpenApi;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class ApplicationOpenApiConfig {

    // TODO: Check proper display on Swagger UI?
    @Bean
    public GroupedOpenApi JcrsApi() {
        return GroupedOpenApi.builder()
                .group("jcrs-public")
                .pathsToMatch("/*/**")
                .build();
    }

    @Bean
    public GroupedOpenApi JcrsAdminApi() {
        return GroupedOpenApi.builder()
                .group("jcrs-admin")
                .pathsToMatch("/admin/**")
                .build();
    }

    @Bean
    public OpenAPI JcrsApiInfo() {
        var license = new License()
                .name(JCRSBase.LICENCE)
                .url(JCRSBase.LICENCE_URL);
        var apiInfo = new Info()
                .title(JCRSBase.APP_NAME)
                .description(JCRSBase.APP_NAME + " RESTful API")
                .version(JCRSBase.API_VERSION)
                .license(license);
        var docs = new ExternalDocumentation()
                .description(JCRSBase.APP_NAME + " Wiki Documentation")
                .url(JCRSBase.WIKI_PAGE);

        return new OpenAPI()
                .info(apiInfo)
                .externalDocs(docs);
    }
}

