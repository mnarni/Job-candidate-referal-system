package jobcandidatereferral;

import jobcandidatereferral.employees.data.EmployeeRepository;
import jobcandidatereferral.employees.model.Employee;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.ActiveProfiles;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;

@DataJpaTest
@ActiveProfiles("test")
public class EmployeeTest {

    @Autowired
    private EmployeeRepository employeeRepository;

    @Test
    void testCrud(){

        var employee= new Employee();
        employee.setFirstName("Sravs");
        employee.setLastName("Park");
        employee.setTitle("Lead");
        employee.setEmail("spark@depaul.edu");
        long beforeCount= employeeRepository.count();
        var beforeUID = employee.getEid();
        employeeRepository.save(employee);
        long afterCount = employeeRepository.count();
        var afterUID= employee.getEid();

        //Check if the employee count increased from before
        assertEquals(beforeCount+1, afterCount);

        //Check if the before UID is different from the newly generated UID
        assertNotEquals(beforeUID, afterUID);

        //Find an existing employee and updating the record
        var updated = employeeRepository.findById(afterUID).orElse(new Employee());
        var title = "QA";
        updated.setTitle(title);
        employeeRepository.save(updated);

        var updatedCheck = employeeRepository.findById(afterUID).orElse(new Employee());
        assertEquals(title, updatedCheck.getTitle());

        beforeCount= employeeRepository.count();
        employeeRepository.delete(updatedCheck);
        afterCount= employeeRepository.count();
        assertEquals(beforeCount-1, afterCount);


    }
}
