package jobcandidatereferral.applications.controller;

import jobcandidatereferral.JCRSBase;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import java.time.LocalDate;

import static jobcandidatereferral.JCRSBase.API_BASE_URL;
import static org.hamcrest.Matchers.containsString;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.ANY)
@ActiveProfiles(JCRSBase.Profiles.TEST)
class JobApplicationRestControllerIT {
    private static final String JSON = MediaType.APPLICATION_JSON_VALUE;

    @Autowired
    private MockMvc mockMvc;

    @Test
    void create() throws Exception {
        String json = """
                {
                  "jobId": 1,
                  "candidateId": 2,
                  "recruiterId": 3,
                  "createdAt": "2023-05-29T08:20:40.529Z",
                  "updatedAt": "2023-05-29T08:20:40.529Z"
                }
                """;

        this.mockMvc.perform(post(API_BASE_URL + "/applications")
                        .content(json).contentType(JSON))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("createdAt")));
    }

    @Test
    void getAll() throws Exception {
        this.mockMvc.perform(get(API_BASE_URL + "/applications"))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("jobs/1")))
                .andExpect(content().string(containsString("recruiters/2")));
    }

    @Test
    void getOne() throws Exception {
        this.mockMvc.perform(get(API_BASE_URL + "/applications/2"))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("candidates/2")));
    }

    @Test
    void update() throws Exception {
        String json = """
                {
                  "jobId": 2,
                  "candidateId": 1,
                  "recruiterId": 3,
                  "createdAt": "2023-05-29T08:20:40.529Z",
                  "updatedAt": "2023-05-29T08:20:40.529Z"
                }
                """;

        this.mockMvc.perform(put(API_BASE_URL + "/applications/2")
                        .content(json).contentType(JSON))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("\"createdAt\":\"" + LocalDate.now())));
    }

    @Test
    void delete() throws Exception {
        this.mockMvc.perform(MockMvcRequestBuilders.delete(API_BASE_URL + "/applications/1"))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("")));
    }
}

