package jobcandidatereferral.applications.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import jobcandidatereferral.JCRSBase;
import jobcandidatereferral.applications.model.Credential;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import static jobcandidatereferral.JCRSBase.API_BASE_URL;
import static org.hamcrest.Matchers.containsString;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.ANY)
@ActiveProfiles(JCRSBase.Profiles.TEST)
class CredentialRestControllerIT {
    private static final String JSON = MediaType.APPLICATION_JSON_VALUE;

    @Autowired
    private MockMvc mockMvc;

    @Test
    void create() throws Exception {
        var entity = Credential.builder()
                .candidateId(3L)
                .schoolId(2)
                .yearsCompleted(2)
                .graduated(true)
                .major("History")
                .type("Master's")
                .build();
        ObjectMapper mapper = new ObjectMapper();
        String json = mapper.writeValueAsString(entity);

        this.mockMvc.perform(post(API_BASE_URL + "/credentials")
                        .content(json).contentType(JSON))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("History")));
    }

    @Test
    void getAll() throws Exception {
        this.mockMvc.perform(get(API_BASE_URL + "/credentials"))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("Master's")))
                .andExpect(content().string(containsString("Bachelor's")));
    }

    @Test
    void getOne() throws Exception {
        this.mockMvc.perform(get(API_BASE_URL + "/credentials/2"))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("Bachelor's Degree")));
    }

    @Test
    void getCredentialsForCandidate() throws Exception {
        this.mockMvc.perform(get(API_BASE_URL + "/credentials/2/credentials"))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("Bachelor's Degree")))
                .andExpect(content().string(containsString("Master's Degree")));
    }

    @Test
    void update() throws Exception {
        var entity = Credential.builder()
                .candidateId(2L)
                .schoolId(1)
                .yearsCompleted(4)
                .graduated(true)
                .major("History")
                .type("Bachelor's Degree")
                .build();
        ObjectMapper mapper = new ObjectMapper();
        String json = mapper.writeValueAsString(entity);

        this.mockMvc.perform(put(API_BASE_URL + "/credentials/2")
                        .content(json).contentType(JSON))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("History")));
    }

    @Test
    void delete() throws Exception {
        this.mockMvc.perform(MockMvcRequestBuilders.delete(API_BASE_URL + "/credentials/1"))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("")));
    }
}

