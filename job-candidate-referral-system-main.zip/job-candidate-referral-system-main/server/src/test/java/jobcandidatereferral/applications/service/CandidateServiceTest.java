package jobcandidatereferral.applications.service;

import jobcandidatereferral.applications.TestData;
import jobcandidatereferral.applications.data.CandidateRepository;
import jobcandidatereferral.applications.model.Candidate;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class CandidateServiceTest {
    @InjectMocks
    private CandidateService service;
    @Mock
    private CandidateRepository repository;

    private Candidate entity;

    @BeforeEach
    void setUp() {
        entity = TestData.createCandidate().toBuilder()
                .id((long) 34)
                .build();
    }

    @Test
    @DisplayName("Create an entity")
    void create() {
        when(repository.save(any(Candidate.class))).thenReturn(entity);

        var newEntity = entity;

        var createdEntity = service.create(newEntity);

        assertNotNull(createdEntity);
        assertEquals(89, createdEntity.getCredentialId());
    }

    @Test
    @DisplayName("Get all entities")
    void getAll() {
        doReturn(getMockEntities()).when(repository).findAll();

        var retrievedEntities = this.service.getAll();
        assertEquals(5, retrievedEntities.size());
    }

    @Test
    @DisplayName("Get one entity")
    void getOne() {
        var entityToReturn = Optional.of(entity);
        doReturn(entityToReturn).when(repository).findById(entity.getId());

        var foundEntity = service.getOne(entity.getId());
        assertNotNull(foundEntity);
        assertTrue(foundEntity.isPresent());
        assertEquals("candidate@email.com", foundEntity.get().getEmail());
    }

    @Test
    @DisplayName("Get one [non-existent] entity")
    void getOneNonExistent() {
        doReturn(Optional.empty()).when(repository).findById(entity.getId());

        assertThrows(NoSuchElementException.class,
                () -> service.getOne(entity.getId()).get(),
                "Exception not thrown as expected!");
    }

    @Test
    @DisplayName("Update an entity")
    void update() {
        when(repository.findById(any(Long.class))).thenReturn(Optional.of(entity));
        when(repository.save(any(Candidate.class))).thenReturn(entity);

        var newEntityInfo = Candidate.builder()
                .id(entity.getId())
                .firstName(entity.getFirstName())
                .lastName(entity.getLastName())
                .referrerId(entity.getReferrerId())
                .credentialId(entity.getCredentialId())
                .previousJobId(entity.getPreviousJobId())
                .refereeId(entity.getRefereeId())
                .email(entity.getEmail())
                .build();

        var updatedEntity = service.update(newEntityInfo, entity.getId());

        assertNotNull(updatedEntity);
        assertEquals("Dut", entity.getFirstName());
    }

    @Test
    @DisplayName("Delete an entity by ID")
    void deleteById() {
        Long id = TestData.createId();
        doNothing().when(repository).deleteById(id);
        service.delete(id);

        assertNotNull(id);
    }

    @Test
    @DisplayName("Delete an entity")
    void deleteWholeObject() {
        doNothing().when(repository).delete(entity);
        service.delete(entity);

        assertNotNull(entity);
    }

    private List<Candidate> getMockEntities() {
        var entities = new ArrayList<Candidate>();

        for (int i = 0; i < 5; i++) {
            entities.add(entity.toBuilder().id((long) i).build());
        }

        return entities;
    }
}