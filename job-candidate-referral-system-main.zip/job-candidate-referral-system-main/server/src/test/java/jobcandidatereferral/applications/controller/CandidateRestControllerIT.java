package jobcandidatereferral.applications.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.servlet.ServletException;
import jobcandidatereferral.JCRSBase;
import jobcandidatereferral.applications.model.Candidate;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import static jobcandidatereferral.JCRSBase.API_BASE_URL;
import static org.hamcrest.Matchers.containsString;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.ANY)
@ActiveProfiles(JCRSBase.Profiles.TEST)
class CandidateRestControllerIT {
    private static final String JSON = MediaType.APPLICATION_JSON_VALUE;

    @Autowired
    private MockMvc mockMvc;

    @Test
    void create() throws Exception {
        var entity = Candidate.builder()
                .firstName("Dut")
                .lastName("A. D.")
                .email("dutad@jcrs.com")
                .referrerId(2L)
                .credentialId(2L)
                .previousJobId(1L)
                .refereeId(3L)
                .militaryAffiliated(true)
                .build();
        ObjectMapper mapper = new ObjectMapper();
        String json = mapper.writeValueAsString(entity);

        this.mockMvc.perform(post(API_BASE_URL + "/candidates")
                        .content(json).contentType(JSON))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("dutad@jcrs.com")));
    }

    @Test
    void getAll() throws Exception {
        this.mockMvc.perform(get(API_BASE_URL + "/candidates"))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("Manut")))
                .andExpect(content().string(containsString("Malual")));
    }

    @Test
    void getOne() throws Exception {
        this.mockMvc.perform(get(API_BASE_URL + "/candidates/2"))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("Bol")));
    }

    @Test
    void update() throws Exception {
        String json = """
                {
                  "firstName": "Dut",
                  "lastName": "A",
                  "email": "dut-a@jcrs.com",
                  "referrerId": 2,
                  "credentialId": 2,
                  "previousJobId": 1,
                  "refereeId": 3,
                  "militaryAffiliated": true
                }
                """;

        this.mockMvc.perform(put(API_BASE_URL + "/candidates/1")
                        .content(json).contentType(JSON))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("\"militaryAffiliated\":true")));
    }

    @Test
    void delete() throws Exception {
        assertThrows(ServletException.class, () ->
                this.mockMvc.perform(
                        MockMvcRequestBuilders.delete(API_BASE_URL + "/candidates/4")));
    }
}

