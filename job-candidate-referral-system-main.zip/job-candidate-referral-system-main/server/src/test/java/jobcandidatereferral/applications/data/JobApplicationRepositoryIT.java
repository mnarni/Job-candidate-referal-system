package jobcandidatereferral.applications.data;

import jobcandidatereferral.JCRSBase;
import jobcandidatereferral.applications.TestData;
import jobcandidatereferral.applications.model.JobApplication;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.context.ActiveProfiles;

import java.time.LocalDate;
import java.time.LocalDateTime;

import static org.assertj.core.api.BDDAssertions.then;
import static org.junit.jupiter.api.Assertions.assertNotNull;

@DataJpaTest
@ActiveProfiles(JCRSBase.Profiles.TEST)
class JobApplicationRepositoryIT {
    @Autowired
    private JobApplicationRepository repo;
    @Autowired
    private TestEntityManager testEntityManager;

    private JobApplication entity;

    @BeforeEach
    void setUp() {
        entity = TestData.createJobApplication();
    }

    @Test
    void create() {
        var savedEntity = repo.save(entity);

        var retrievedEntity = testEntityManager.find(JobApplication.class, savedEntity.getId());

        then(retrievedEntity.getCreatedAt()).hasYear(LocalDate.now().getYear());
        then(savedEntity.getId()).isNotNull();
        then(savedEntity.getJobId()).isEqualTo(entity.getJobId());
    }

    @Test
    void getOne() {
        var savedEntity = testEntityManager.persistFlushFind(entity);
        var retrievedEntity = repo.findById(savedEntity.getId());

        then(savedEntity.getId()).isNotNull();
        then(retrievedEntity.isPresent()).isTrue();
        then(retrievedEntity.get().getCandidateId()).isEqualTo(savedEntity.getCandidateId());
    }

    @Test
    void update() {
        var savedEntity = repo.save(entity);
        var retrievedEntity = testEntityManager.find(JobApplication.class, savedEntity.getId());
        var updatedEntity = repo.save(retrievedEntity.toBuilder().recruiterId(9L).updatedAt(LocalDateTime.now()).build());

        assertNotNull(updatedEntity.getUpdatedAt());
        then(updatedEntity.getRecruiterId()).isEqualTo(9);
        then(savedEntity.getJobId()).isEqualTo(updatedEntity.getJobId());
    }

    @Test
    void delete() {
        var savedEntity = repo.save(entity);
        var retrievedEntity = testEntityManager.find(JobApplication.class, savedEntity.getId());

        then(retrievedEntity.getCandidateId()).isEqualTo(3);
        then(savedEntity.getJobId()).isEqualTo(retrievedEntity.getJobId());

        repo.delete(retrievedEntity);

        var retrievedEntityAfterDeletion = testEntityManager.find(JobApplication.class, retrievedEntity.getId());

        then(retrievedEntityAfterDeletion).isNull();
    }
}

