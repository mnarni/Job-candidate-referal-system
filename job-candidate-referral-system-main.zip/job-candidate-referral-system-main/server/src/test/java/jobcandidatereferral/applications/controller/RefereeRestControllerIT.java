package jobcandidatereferral.applications.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import jobcandidatereferral.JCRSBase;
import jobcandidatereferral.applications.model.Referee;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import static jobcandidatereferral.JCRSBase.API_BASE_URL;
import static org.hamcrest.Matchers.containsString;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.ANY)
@ActiveProfiles(JCRSBase.Profiles.TEST)
class RefereeRestControllerIT {
    private static final String JSON = MediaType.APPLICATION_JSON_VALUE;

    @Autowired
    private MockMvc mockMvc;

    @Test
    void create() throws Exception {
        var entity = Referee.builder()
                .candidateId(3L)
                .firstName("Malek")
                .lastName("Lual")
                .email("malek.lual@ymail.com")
                .phoneNumber("312-555-1238")
                .preferredContact("Email")
                .build();
        ObjectMapper mapper = new ObjectMapper();

        String json = mapper.writeValueAsString(entity);

        this.mockMvc.perform(post(API_BASE_URL + "/referees")
                        .content(json).contentType(JSON))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("malek.lual@ymail.com")));
    }

    @Test
    void getAll() throws Exception {
        this.mockMvc.perform(get(API_BASE_URL + "/referees"))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("Malek")))
                .andExpect(content().string(containsString("Dine")));
    }

    @Test
    void getOne() throws Exception {
        this.mockMvc.perform(get(API_BASE_URL + "/referees/2"))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("Joseph")));
    }

    @Test
    void getRefereesForCandidate() throws Exception {
        this.mockMvc.perform(get(API_BASE_URL + "/referees/1/referees"))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("Digla")))
                .andExpect(content().string(containsString("Udom")));
    }

    @Test
    void update() throws Exception {
        var entity = Referee.builder()
                .candidateId(2L)
                .firstName("Joseph")
                .lastName("Dine")
                .email("jdine@gmail.com")
                .phoneNumber("312-555-1238")
                .preferredContact("Email")
                .build();
        ObjectMapper mapper = new ObjectMapper();
        String json = mapper.writeValueAsString(entity);

        this.mockMvc.perform(put(API_BASE_URL + "/referees/2")
                        .content(json).contentType(JSON))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("jdine@gmail.com")));
    }

    @Test
    void delete() throws Exception {
        this.mockMvc.perform(MockMvcRequestBuilders.delete(API_BASE_URL + "/referees/1"))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("")));
    }
}

