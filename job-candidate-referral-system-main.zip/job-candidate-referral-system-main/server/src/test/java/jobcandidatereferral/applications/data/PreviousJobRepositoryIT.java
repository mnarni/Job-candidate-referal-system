package jobcandidatereferral.applications.data;

import jobcandidatereferral.JCRSBase;
import jobcandidatereferral.applications.TestData;
import jobcandidatereferral.applications.model.PreviousJob;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.context.ActiveProfiles;

import java.time.LocalDate;
import java.time.LocalDateTime;

import static org.assertj.core.api.BDDAssertions.then;
import static org.junit.jupiter.api.Assertions.assertNotNull;

@DataJpaTest
@ActiveProfiles(JCRSBase.Profiles.TEST)
class PreviousJobRepositoryIT {
    @Autowired
    private PreviousJobRepository repo;
    @Autowired
    private TestEntityManager testEntityManager;

    private PreviousJob entity;

    @BeforeEach
    void setUp() {
        entity = TestData.createPreviousJob();
    }

    @Test
    void create() {
        var savedEntity = repo.save(entity);

        var retrievedEntity = testEntityManager.find(PreviousJob.class, savedEntity.getId());

        then(retrievedEntity.getCreatedAt()).hasYear(LocalDate.now().getYear());
        then(savedEntity.getId()).isNotNull();
        then(savedEntity.getTitle()).isEqualTo(entity.getTitle());
    }

    @Test
    void getOne() {
        var savedEntity = testEntityManager.persistFlushFind(entity);
        var retrievedEntity = repo.findById(savedEntity.getId());

        then(savedEntity.getId()).isNotNull();
        then(retrievedEntity.isPresent()).isTrue();
        then(retrievedEntity.get().getCandidateId()).isEqualTo(savedEntity.getCandidateId());
    }

    @Test
    void update() {
        var savedEntity = repo.save(entity);
        var retrievedEntity = testEntityManager.find(PreviousJob.class, savedEntity.getId());
        var updatedEntity = repo.save(retrievedEntity.toBuilder().level("Expert").updatedAt(LocalDateTime.now()).build());

        assertNotNull(updatedEntity.getUpdatedAt());
        then(updatedEntity.getLevel()).isEqualTo("Expert");
        then(savedEntity.getTitle()).isEqualTo(updatedEntity.getTitle());
    }

    @Test
    void delete() {
        var savedEntity = repo.save(entity);
        var retrievedEntity = testEntityManager.find(PreviousJob.class, savedEntity.getId());

        then(retrievedEntity.getCandidateId()).isEqualTo(2);
        then(savedEntity.getCandidateId()).isEqualTo(retrievedEntity.getCandidateId());

        repo.delete(retrievedEntity);

        var retrievedEntityAfterDeletion = testEntityManager.find(PreviousJob.class, retrievedEntity.getId());

        then(retrievedEntityAfterDeletion).isNull();
    }
}

