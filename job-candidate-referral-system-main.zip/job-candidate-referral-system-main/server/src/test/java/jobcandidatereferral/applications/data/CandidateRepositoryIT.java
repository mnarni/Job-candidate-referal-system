package jobcandidatereferral.applications.data;

import jobcandidatereferral.JCRSBase;
import jobcandidatereferral.applications.TestData;
import jobcandidatereferral.applications.model.Candidate;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.context.ActiveProfiles;

import java.time.LocalDate;
import java.time.LocalDateTime;

import static org.assertj.core.api.BDDAssertions.then;
import static org.junit.jupiter.api.Assertions.assertNotNull;

@DataJpaTest
@ActiveProfiles(JCRSBase.Profiles.TEST)
class CandidateRepositoryIT {
    @Autowired
    private CandidateRepository repo;
    @Autowired
    private TestEntityManager testEntityManager;

    private Candidate entity;

    @BeforeEach
    void setUp() {
        entity = TestData.createCandidate();
    }

    @Test
    void create() {
        var savedEntity = repo.save(entity);

        var retrievedEntity = testEntityManager.find(Candidate.class, savedEntity.getId());

        then(retrievedEntity.getCreatedAt()).hasYear(LocalDate.now().getYear());
        then(savedEntity.getId()).isNotNull();
        then(savedEntity.getCredentialId()).isEqualTo(entity.getCredentialId());
    }

    @Test
    void getOne() {
        var savedEntity = testEntityManager.persistFlushFind(entity);
        var retrievedEntity = repo.findById(savedEntity.getId());

        then(savedEntity.getId()).isNotNull();
        then(retrievedEntity.isPresent()).isTrue();
        then(retrievedEntity.get().getCredentialId()).isEqualTo(savedEntity.getCredentialId());
    }

    @Test
    void update() {
        var savedEntity = repo.save(entity);
        var retrievedEntity = testEntityManager.find(Candidate.class, savedEntity.getId());
        var updatedEntity = repo.save(retrievedEntity.toBuilder().refereeId(9L).updatedAt(LocalDateTime.now()).build());

        assertNotNull(updatedEntity.getUpdatedAt());
        then(updatedEntity.getRefereeId()).isEqualTo(9);
        then(savedEntity.getCredentialId()).isEqualTo(updatedEntity.getCredentialId());
    }

    @Test
    void delete() {
        var savedEntity = repo.save(entity);
        var retrievedEntity = testEntityManager.find(Candidate.class, savedEntity.getId());

        then(retrievedEntity.getCredentialId()).isEqualTo(89);
        then(savedEntity.getCredentialId()).isEqualTo(retrievedEntity.getCredentialId());

        repo.delete(retrievedEntity);

        var retrievedEntityAfterDeletion = testEntityManager.find(Candidate.class, retrievedEntity.getId());

        then(retrievedEntityAfterDeletion).isNull();
    }
}
