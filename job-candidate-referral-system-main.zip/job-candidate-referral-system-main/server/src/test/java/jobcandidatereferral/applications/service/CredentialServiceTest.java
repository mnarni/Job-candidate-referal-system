package jobcandidatereferral.applications.service;

import jobcandidatereferral.applications.TestData;
import jobcandidatereferral.applications.data.CredentialRepository;
import jobcandidatereferral.applications.model.Credential;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class CredentialServiceTest {
    @InjectMocks
    private CredentialService service;
    @Mock
    private CredentialRepository repository;

    private Credential entity;

    @BeforeEach
    void setUp() {
        entity = TestData.createCredential().toBuilder()
                .id((long) 35)
                .build();
    }

    @Test
    @DisplayName("Create an entity")
    void create() {
        when(repository.save(any(Credential.class))).thenReturn(entity);

        var newEntity = entity;

        var createdEntity = service.create(newEntity);

        assertNotNull(createdEntity);
        assertEquals(2, createdEntity.getSchoolId());
    }

    @Test
    @DisplayName("Get all entities")
    void getAll() {
        doReturn(getMockEntities()).when(repository).findAll();

        var retrievedEntities = service.getAll();
        assertEquals(5, retrievedEntities.size());
    }

    @Test
    @DisplayName("Get all credentials for a candidate")
    void getCredentialsForCandidate() {
        doReturn(getMockEntities()).when(repository).findCredentialsByCandidateId(any(Long.class));

        var retrievedCredentials = service.getCredentialsForCandidate(7L);
        assertEquals(5, retrievedCredentials.size());
    }

    @Test
    @DisplayName("Get one entity")
    void getOne() {
        var entityToReturn = Optional.of(entity);
        doReturn(entityToReturn).when(repository).findById(entity.getId());

        var foundEntity = service.getOne(entity.getId());
        assertNotNull(foundEntity);
        assertTrue(foundEntity.isPresent());
        assertEquals(4, foundEntity.get().getYearsCompleted());
    }

    @Test
    @DisplayName("Get one [non-existent] entity")
    void getOneNonExistent() {
        doReturn(Optional.empty()).when(repository).findById(entity.getId());

        assertThrows(NoSuchElementException.class,
                () -> service.getOne(entity.getId()).get(),
                "Exception not thrown as expected!");
    }

    @Test
    @DisplayName("Update an entity")
    void update() {
        when(repository.findById(any(Long.class))).thenReturn(Optional.of(entity));
        when(repository.save(any(Credential.class))).thenReturn(entity);

        var newEntityInfo = entity.toBuilder()
                .major("Software Engineering")
                .yearsCompleted(3)
                .build();

        var updatedEntity = service.update(newEntityInfo, entity.getId());

        assertNotNull(updatedEntity);
        assertEquals("Computer Science", entity.getMajor());
    }

    @Test
    @DisplayName("Delete an entity by ID")
    void deleteById() {
        Long id = TestData.createId();
        doNothing().when(repository).deleteById(id);
        service.delete(id);

        assertNotNull(id);
    }

    @Test
    @DisplayName("Delete an entity")
    void deleteWholeObject() {
        doNothing().when(repository).delete(entity);
        service.delete(entity);

        assertNotNull(entity);
    }

    private List<Credential> getMockEntities() {
        var entities = new ArrayList<Credential>();

        for (int i = 0; i < 5; i++) {
            entities.add(entity.toBuilder().id((long) i).build());
        }

        return entities;
    }
}