
package jobcandidatereferral.applications.data;

import jobcandidatereferral.JCRSBase;
import jobcandidatereferral.applications.TestData;
import jobcandidatereferral.applications.model.Credential;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.context.ActiveProfiles;

import java.time.LocalDate;
import java.time.LocalDateTime;

import static org.assertj.core.api.BDDAssertions.then;
import static org.junit.jupiter.api.Assertions.assertNotNull;

@DataJpaTest
@ActiveProfiles(JCRSBase.Profiles.TEST)
class CredentialRepositoryIT {
    @Autowired
    private CredentialRepository repo;
    @Autowired
    private TestEntityManager testEntityManager;

    private Credential entity;

    @BeforeEach
    void setUp() {
        entity = TestData.createCredential();
    }

    @Test
    void create() {
        var savedEntity = repo.save(entity);

        var retrievedEntity = testEntityManager.find(Credential.class, savedEntity.getId());

        then(retrievedEntity.getCreatedAt()).hasYear(LocalDate.now().getYear());
        then(savedEntity.getId()).isNotNull();
        then(savedEntity.getMajor()).isEqualTo(entity.getMajor());
    }

    @Test
    void getOne() {
        var savedEntity = testEntityManager.persistFlushFind(entity);
        var retrievedEntity = repo.findById(savedEntity.getId());

        then(savedEntity.getId()).isNotNull();
        then(retrievedEntity.isPresent()).isTrue();
        then(retrievedEntity.get().getCandidateId()).isEqualTo(savedEntity.getCandidateId());
    }

    @Test
    void update() {
        var savedEntity = repo.save(entity);
        var retrievedEntity = testEntityManager.find(Credential.class, savedEntity.getId());
        var updatedEntity = repo.save(retrievedEntity.toBuilder().schoolId(9).updatedAt(LocalDateTime.now()).build());

        assertNotNull(updatedEntity.getUpdatedAt());
        then(updatedEntity.getSchoolId()).isEqualTo(9);
        then(savedEntity.getCandidateId()).isEqualTo(updatedEntity.getCandidateId());
    }

    @Test
    void delete() {
        var savedEntity = repo.save(entity);
        var retrievedEntity = testEntityManager.find(Credential.class, savedEntity.getId());

        then(retrievedEntity.getCandidateId()).isEqualTo(2);
        then(savedEntity.getCandidateId()).isEqualTo(retrievedEntity.getCandidateId());

        repo.delete(retrievedEntity);

        var retrievedEntityAfterDeletion = testEntityManager.find(Credential.class, retrievedEntity.getId());

        then(retrievedEntityAfterDeletion).isNull();
    }
}

