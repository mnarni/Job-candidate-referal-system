package jobcandidatereferral.applications;

import jobcandidatereferral.applications.model.*;
import jobcandidatereferral.employees.model.Recruiter;

import java.time.LocalDateTime;
import java.util.Random;

public class TestData {

    public static Candidate createCandidate() {
        return Candidate.builder()
                .firstName("Dut")
                .lastName("A")
                .referrerId(3L)
                .credentialId(89L)
                .previousJobId(7L)
                .refereeId(8L)
                .email("candidate@email.com")
                .createdAt(LocalDateTime.now())
                .build();
    }

    public static Credential createCredential() {
        return Credential.builder()
                .candidateId(2L)
                .schoolId(2)
                .yearsCompleted(4)
                .graduated(true)
                .major("Computer Science")
                .type("Bachelor's")
                .createdAt(LocalDateTime.now())
                .build();
    }

    public static JobApplication createJobApplication() {
        return JobApplication.builder()
                .jobId(2L)
                .candidateId(3L)
                .recruiterId(2L)
                .createdAt(LocalDateTime.now())
                .build();
    }

    public static PreviousJob createPreviousJob() {
        return PreviousJob.builder()
                .candidateId(2L)
                .title("Android Developer")
                .level("Senior")
                .description("Responsible for the entire SDLC in a startup shop")
                .createdAt(LocalDateTime.now())
                .build();
    }

    public static Referee createReferee() {
        return Referee.builder()
                .candidateId(1L)
                .firstName("Cinderella")
                .lastName("Micky")
                .email("ucu@jcrs.com")
                .createdAt(LocalDateTime.now())
                .build();
    }

    public static long createId() {
        return Long.parseLong(String.valueOf(new Random(34).nextInt()));
    }
}

