## All milestones are located in src/main/resources/submissions/


## Daniel Dut
- Email: Ddut@depaul.edu
- Role: Back End Dev

## Jayden Godbold
- Email: Godbold.j301@gmail.com
- Role: Front End Dev

## Monica Narni
- Email: mnarni@depaul.edu
- Role: Front End Dev

## Marcel Alfonso Garcia
Email: malfons1@depaul.edu
Role: Tech Lead

